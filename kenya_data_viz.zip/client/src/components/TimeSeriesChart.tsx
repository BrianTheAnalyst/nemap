import { useEffect, useRef } from "react";
import * as d3 from "d3";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

interface DataPoint {
  year: number;
  value: number;
}

interface TimeSeriesChartProps {
  data: DataPoint[];
  title: string;
  yAxisLabel: string;
  valueFormatter?: (value: number) => string;
  onDownload?: () => void;
}

const ELECTION_YEARS = [2013, 2017, 2022];

export default function TimeSeriesChart({
  data,
  title,
  yAxisLabel,
  valueFormatter = (v) => v.toLocaleString(),
  onDownload,
}: TimeSeriesChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || data.length === 0) return;

    // Clear previous chart
    d3.select(svgRef.current).selectAll("*").remove();

    // Get container dimensions
    const containerWidth = containerRef.current.clientWidth;
    const containerHeight = 240;
    const margin = { top: 20, right: 30, bottom: 40, left: 60 };
    const width = containerWidth - margin.left - margin.right;
    const height = containerHeight - margin.top - margin.bottom;

    // Create SVG
    const svg = d3
      .select(svgRef.current)
      .attr("width", containerWidth)
      .attr("height", containerHeight)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Create scales
    const xScale = d3
      .scaleLinear()
      .domain(d3.extent(data, (d) => d.year) as [number, number])
      .range([0, width]);

    const yScale = d3
      .scaleLinear()
      .domain([0, d3.max(data, (d) => d.value) as number])
      .nice()
      .range([height, 0]);

    // Add grid lines
    svg
      .append("g")
      .attr("class", "grid")
      .selectAll("line")
      .data(yScale.ticks(5))
      .enter()
      .append("line")
      .attr("x1", 0)
      .attr("x2", width)
      .attr("y1", (d) => yScale(d))
      .attr("y2", (d) => yScale(d))
      .attr("class", "d3-chart-grid");

    // Add X axis
    const xAxis = d3.axisBottom(xScale).tickFormat((d) => d.toString()).ticks(data.length);
    svg
      .append("g")
      .attr("transform", `translate(0,${height})`)
      .attr("class", "d3-chart-axis")
      .call(xAxis);

    // Add Y axis
    const yAxis = d3.axisLeft(yScale).ticks(5).tickFormat((d) => valueFormatter(d as number));
    svg.append("g").attr("class", "d3-chart-axis").call(yAxis);

    // Add Y axis label
    svg
      .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - margin.left)
      .attr("x", 0 - height / 2)
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .attr("class", "text-xs text-muted-foreground fill-current")
      .text(yAxisLabel);

    // Add election cycle markers
    ELECTION_YEARS.forEach((year) => {
      if (year >= (d3.min(data, (d) => d.year) as number) && year <= (d3.max(data, (d) => d.year) as number)) {
        svg
          .append("line")
          .attr("x1", xScale(year))
          .attr("x2", xScale(year))
          .attr("y1", 0)
          .attr("y2", height)
          .attr("class", "election-marker");

        svg
          .append("text")
          .attr("x", xScale(year))
          .attr("y", -5)
          .attr("text-anchor", "middle")
          .attr("class", "text-xs font-medium fill-primary")
          .text(`${year}`);
      }
    });

    // Create line generator
    const line = d3
      .line<DataPoint>()
      .x((d) => xScale(d.year))
      .y((d) => yScale(d.value))
      .curve(d3.curveMonotoneX);

    // Add line path
    const path = svg
      .append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "hsl(var(--primary))")
      .attr("stroke-width", 2.5)
      .attr("d", line);

    // Animate line drawing
    const pathLength = path.node()?.getTotalLength() || 0;
    path
      .attr("stroke-dasharray", `${pathLength} ${pathLength}`)
      .attr("stroke-dashoffset", pathLength)
      .transition()
      .duration(1000)
      .ease(d3.easeLinear)
      .attr("stroke-dashoffset", 0);

    // Add data points
    svg
      .selectAll(".dot")
      .data(data)
      .enter()
      .append("circle")
      .attr("class", "dot")
      .attr("cx", (d) => xScale(d.year))
      .attr("cy", (d) => yScale(d.value))
      .attr("r", 4)
      .attr("fill", "hsl(var(--primary))")
      .attr("stroke", "hsl(var(--background))")
      .attr("stroke-width", 2)
      .style("opacity", 0)
      .transition()
      .delay((d, i) => i * 100)
      .duration(300)
      .style("opacity", 1);

    // Add tooltip
    const tooltip = d3
      .select("body")
      .append("div")
      .attr("class", "d3-chart-tooltip")
      .style("position", "absolute")
      .style("visibility", "hidden")
      .style("pointer-events", "none")
      .style("z-index", 1000);

    // Add invisible overlay for hover detection
    svg
      .selectAll(".hover-circle")
      .data(data)
      .enter()
      .append("circle")
      .attr("cx", (d) => xScale(d.year))
      .attr("cy", (d) => yScale(d.value))
      .attr("r", 15)
      .attr("fill", "transparent")
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        tooltip
          .style("visibility", "visible")
          .html(
            `
            <div class="font-semibold">${d.year}</div>
            <div class="text-muted-foreground">${valueFormatter(d.value)}</div>
          `
          );

        const parent = d3.select(this).node()?.parentNode as Element;
        if (parent) {
          d3.select(parent)
            .selectAll(".dot")
            .filter((dotData: any) => dotData.year === d.year)
            .transition()
            .duration(200)
            .attr("r", 6);
        }
      })
      .on("mousemove", function (event) {
        tooltip.style("top", event.pageY - 50 + "px").style("left", event.pageX + 10 + "px");
      })
      .on("mouseout", function (event, d) {
        tooltip.style("visibility", "hidden");

        const parent = d3.select(this).node()?.parentNode as Element;
        if (parent) {
          d3.select(parent)
            .selectAll(".dot")
            .filter((dotData: any) => dotData.year === d.year)
            .transition()
            .duration(200)
            .attr("r", 4);
        }
      });

    // Cleanup
    return () => {
      tooltip.remove();
    };
  }, [data, yAxisLabel, valueFormatter]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">{title}</h3>
        {onDownload && (
          <Button variant="ghost" size="sm" onClick={onDownload} className="h-7 gap-1 text-xs">
            <Download className="h-3 w-3" />
            PNG
          </Button>
        )}
      </div>
      <div ref={containerRef} className="w-full">
        <svg ref={svgRef} className="w-full"></svg>
      </div>
    </div>
  );
}
