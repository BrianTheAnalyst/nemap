import { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, Maximize2, RotateCcw } from "lucide-react";

// Use Mapbox public token for demo purposes
mapboxgl.accessToken = "pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw";

interface MapVisualizationProps {
  selectedIndicator: string;
  indicatorType: "economic" | "political";
  selectedYear: number;
  onRegionClick?: (regionCode: string, regionName: string) => void;
}

export default function MapVisualization({
  selectedIndicator,
  indicatorType,
  selectedYear,
  onRegionClick,
}: MapVisualizationProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const popup = useRef<mapboxgl.Popup | null>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/light-v11",
      center: [37.9062, 0.0236], // Kenya center
      zoom: 5.5,
      minZoom: 5,
      maxZoom: 12,
    });

    // Add navigation controls
    map.current.addControl(new mapboxgl.NavigationControl(), "top-right");
    map.current.addControl(new mapboxgl.FullscreenControl(), "top-right");

    // Initialize popup
    popup.current = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
    });

    // Suppress tile loading errors (they don't affect our GeoJSON polygons)
    map.current.on("error", (e) => {
      // Only suppress tile loading errors, not other errors
      if (e.error?.message?.includes("NetworkError") || e.error?.message === "Unknown error") {
        // Silently ignore tile loading errors
        return;
      }
      // Log other errors for debugging
      console.error("Map error:", e.error);
    });

    map.current.on("load", () => {
      setIsMapLoaded(true);
      loadKenyaBoundaries();
    });

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  // Load Kenya boundaries (sample GeoJSON data)
  const loadKenyaBoundaries = () => {
    if (!map.current) return;

    // Sample GeoJSON for Kenya counties (simplified for demo)
    const kenyaCountiesGeoJSON = {
      type: "FeatureCollection" as const,
      features: [
        {
          type: "Feature" as const,
          properties: {
            code: "county-001",
            name: "Nairobi",
            gcp: 1200000000000,
            population: 4397073,
            poverty_rate: 28.5,
          },
          geometry: {
            type: "Polygon" as const,
            coordinates: [
              [
                [36.65, -1.45],
                [37.1, -1.45],
                [37.1, -1.15],
                [36.65, -1.15],
                [36.65, -1.45],
              ],
            ],
          },
        },
        {
          type: "Feature" as const,
          properties: {
            code: "county-002",
            name: "Mombasa",
            gcp: 450000000000,
            population: 1208333,
            poverty_rate: 32.1,
          },
          geometry: {
            type: "Polygon" as const,
            coordinates: [
              [
                [39.5, -4.2],
                [39.8, -4.2],
                [39.8, -3.9],
                [39.5, -3.9],
                [39.5, -4.2],
              ],
            ],
          },
        },
        {
          type: "Feature" as const,
          properties: {
            code: "county-003",
            name: "Kisumu",
            gcp: 380000000000,
            population: 1155574,
            poverty_rate: 42.3,
          },
          geometry: {
            type: "Polygon" as const,
            coordinates: [
              [
                [34.5, -0.3],
                [35.0, -0.3],
                [35.0, 0.2],
                [34.5, 0.2],
                [34.5, -0.3],
              ],
            ],
          },
        },
        {
          type: "Feature" as const,
          properties: {
            code: "county-004",
            name: "Nakuru",
            gcp: 520000000000,
            population: 2162202,
            poverty_rate: 35.7,
          },
          geometry: {
            type: "Polygon" as const,
            coordinates: [
              [
                [35.8, -1.2],
                [36.5, -1.2],
                [36.5, -0.2],
                [35.8, -0.2],
                [35.8, -1.2],
              ],
            ],
          },
        },
        {
          type: "Feature" as const,
          properties: {
            code: "county-005",
            name: "Kiambu",
            gcp: 680000000000,
            population: 2417735,
            poverty_rate: 26.8,
          },
          geometry: {
            type: "Polygon" as const,
            coordinates: [
              [
                [36.5, -1.45],
                [37.2, -1.45],
                [37.2, -0.8],
                [36.5, -0.8],
                [36.5, -1.45],
              ],
            ],
          },
        },
      ],
    };

    // Add source
    map.current!.addSource("kenya-counties", {
      type: "geojson",
      data: kenyaCountiesGeoJSON,
    });

    // Add fill layer
    map.current!.addLayer({
      id: "counties-fill",
      type: "fill",
      source: "kenya-counties",
      paint: {
        "fill-color": [
          "interpolate",
          ["linear"],
          ["get", "gcp"],
          300000000000,
          "#FEF3C7", // Yellow (low)
          700000000000,
          "#86EFAC", // Light green
          1200000000000,
          "#10B981", // Green (high)
        ],
        "fill-opacity": 0.7,
      },
    });

    // Add border layer
    map.current!.addLayer({
      id: "counties-border",
      type: "line",
      source: "kenya-counties",
      paint: {
        "line-color": "#64748b",
        "line-width": 1.5,
      },
    });

    // Add hover effect
    map.current!.on("mousemove", "counties-fill", (e) => {
      if (!e.features || e.features.length === 0) return;

      map.current!.getCanvas().style.cursor = "pointer";

      const feature = e.features[0];
      const coordinates = e.lngLat;
      const name = feature.properties?.name;
      const gcp = feature.properties?.gcp;
      const population = feature.properties?.population;

      const gcpFormatted = new Intl.NumberFormat("en-KE", {
        style: "currency",
        currency: "KES",
        notation: "compact",
        maximumFractionDigits: 1,
      }).format(gcp);

      const popFormatted = new Intl.NumberFormat("en-KE", {
        notation: "compact",
        maximumFractionDigits: 1,
      }).format(population);

      popup.current
        ?.setLngLat(coordinates)
        .setHTML(
          `
          <div class="text-sm">
            <div class="font-semibold text-foreground mb-1">${name}</div>
            <div class="text-muted-foreground space-y-0.5">
              <div>GCP: ${gcpFormatted}</div>
              <div>Population: ${popFormatted}</div>
            </div>
          </div>
        `
        )
        .addTo(map.current!);
    });

    map.current!.on("mouseleave", "counties-fill", () => {
      map.current!.getCanvas().style.cursor = "";
      popup.current?.remove();
    });

    // Add click handler for drill-down
    map.current!.on("click", "counties-fill", (e) => {
      if (!e.features || e.features.length === 0) return;

      const feature = e.features[0];
      const code = feature.properties?.code;
      const name = feature.properties?.name;

      if (onRegionClick && code && name) {
        onRegionClick(code, name);

        // Zoom to clicked region with smooth animation
        if (feature.geometry.type === "Polygon") {
          const coordinates = feature.geometry.coordinates[0];
          const bounds = coordinates.reduce(
            (bounds, coord) => {
              return bounds.extend(coord as [number, number]);
            },
            new mapboxgl.LngLatBounds(coordinates[0] as [number, number], coordinates[0] as [number, number])
          );

          map.current!.fitBounds(bounds, {
            padding: 100,
            duration: 500,
          });
        }
      }
    });
  };

  // Update choropleth colors based on selected indicator
  useEffect(() => {
    if (!map.current || !isMapLoaded) return;

    const layer = map.current.getLayer("counties-fill");
    if (!layer) return;

    let colorExpression: mapboxgl.Expression;

    if (indicatorType === "economic") {
      if (selectedIndicator === "gcp_current_prices") {
        colorExpression = [
          "interpolate",
          ["linear"],
          ["get", "gcp"],
          300000000000,
          "#FEF3C7",
          700000000000,
          "#86EFAC",
          1200000000000,
          "#10B981",
        ];
      } else if (selectedIndicator === "poverty_headcount") {
        colorExpression = [
          "interpolate",
          ["linear"],
          ["get", "poverty_rate"],
          20,
          "#86EFAC",
          35,
          "#FCD34D",
          50,
          "#F87171",
        ];
      } else {
        // population_estimate
        colorExpression = [
          "interpolate",
          ["linear"],
          ["get", "population"],
          500000,
          "#DBEAFE",
          1500000,
          "#60A5FA",
          3000000,
          "#2563EB",
        ];
      }
    } else {
      // Political indicators - use categorical colors
      colorExpression = ["match", ["get", "party"], "blue", "#3B82F6", "red", "#EF4444", "#9CA3AF"];
    }

    map.current.setPaintProperty("counties-fill", "fill-color", colorExpression);
  }, [selectedIndicator, indicatorType, isMapLoaded]);

  const handleZoomIn = () => {
    map.current?.zoomIn({ duration: 300 });
  };

  const handleZoomOut = () => {
    map.current?.zoomOut({ duration: 300 });
  };

  const handleResetView = () => {
    map.current?.flyTo({
      center: [37.9062, 0.0236],
      zoom: 5.5,
      duration: 500,
    });
  };

  const handleFullscreen = () => {
    if (!mapContainer.current) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      mapContainer.current.requestFullscreen();
    }
  };

  return (
    <div className="absolute inset-0 w-full h-full">
      {/* Map Container */}
      <div ref={mapContainer} className="map-container" />

      {/* Custom Controls (Bottom Left) */}
      <div className="absolute bottom-6 left-6 z-10 flex flex-col gap-2">
        <Button variant="secondary" size="icon" onClick={handleZoomIn} title="Zoom In">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleZoomOut} title="Zoom Out">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleResetView} title="Reset View">
          <RotateCcw className="h-4 w-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleFullscreen} title="Fullscreen">
          <Maximize2 className="h-4 w-4" />
        </Button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-6 right-6 z-10 bg-card border border-border rounded-lg shadow-lg p-4 max-w-xs">
        <h3 className="text-sm font-semibold mb-2">
          {indicatorType === "economic" ? "Economic Indicator" : "Political Indicator"}
        </h3>
        <div className="space-y-2">
          {indicatorType === "economic" && selectedIndicator === "gcp_current_prices" && (
            <>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#FEF3C7" }}></div>
                <span className="text-xs text-muted-foreground">Low (KSh 300B)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#86EFAC" }}></div>
                <span className="text-xs text-muted-foreground">Medium (KSh 700B)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#10B981" }}></div>
                <span className="text-xs text-muted-foreground">High (KSh 1.2T)</span>
              </div>
            </>
          )}
          {indicatorType === "economic" && selectedIndicator === "poverty_headcount" && (
            <>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#86EFAC" }}></div>
                <span className="text-xs text-muted-foreground">Low (&lt;25%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#FCD34D" }}></div>
                <span className="text-xs text-muted-foreground">Medium (25-40%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#F87171" }}></div>
                <span className="text-xs text-muted-foreground">High (&gt;40%)</span>
              </div>
            </>
          )}
          {indicatorType === "economic" && selectedIndicator === "population_estimate" && (
            <>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#DBEAFE" }}></div>
                <span className="text-xs text-muted-foreground">Low (&lt;1M)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#60A5FA" }}></div>
                <span className="text-xs text-muted-foreground">Medium (1-2M)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 rounded" style={{ backgroundColor: "#2563EB" }}></div>
                <span className="text-xs text-muted-foreground">High (&gt;2M)</span>
              </div>
            </>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-3">
          Click a region to drill down • Hover for details
        </p>
      </div>
    </div>
  );
}
