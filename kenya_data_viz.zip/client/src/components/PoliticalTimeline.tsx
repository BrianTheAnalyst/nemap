import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface Official {
  year: number;
  name: string;
  party: string;
  partyColor: string;
  position: string;
}

interface PoliticalTimelineProps {
  officials: Official[];
  title?: string;
}

const getPartyColor = (party: string): string => {
  const partyColors: Record<string, string> = {
    "Jubilee": "oklch(var(--party-blue))",
    "ODM": "oklch(var(--party-red))",
    "UDA": "oklch(var(--party-amber))",
    "KANU": "oklch(var(--party-red))",
    "Independent": "oklch(var(--party-neutral))",
  };
  return partyColors[party] || "oklch(var(--party-neutral))";
};

export default function PoliticalTimeline({
  officials,
  title = "Political Timeline",
}: PoliticalTimelineProps) {
  if (officials.length === 0) {
    return (
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3">{title}</h3>
        <div className="text-sm text-muted-foreground text-center py-4">
          No political data available for this region
        </div>
      </Card>
    );
  }

  // Sort officials by year
  const sortedOfficials = [...officials].sort((a, b) => a.year - b.year);

  return (
    <Card className="p-4">
      <h3 className="text-sm font-semibold mb-3">{title}</h3>
      <div className="space-y-3">
        {sortedOfficials.map((official, index) => (
          <div key={index} className="flex items-start gap-3">
            {/* Year Badge */}
            <div className="flex-shrink-0 w-16">
              <Badge variant="outline" className="text-xs font-medium">
                {official.year}
              </Badge>
            </div>

            {/* Timeline Line */}
            <div className="flex flex-col items-center flex-shrink-0">
              <Avatar
                className="h-8 w-8 border-2"
                style={{ borderColor: getPartyColor(official.party) }}
              >
                <AvatarFallback
                  className="text-xs font-semibold"
                  style={{
                    backgroundColor: `${getPartyColor(official.party)}20`,
                    color: getPartyColor(official.party),
                  }}
                >
                  {official.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()
                    .slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              {index < sortedOfficials.length - 1 && (
                <div className="w-0.5 h-8 bg-border mt-1"></div>
              )}
            </div>

            {/* Official Details */}
            <div className="flex-1 min-w-0 pt-1">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate">
                    {official.name}
                  </p>
                  <p className="text-xs text-muted-foreground">{official.position}</p>
                </div>
                <Badge
                  variant="secondary"
                  className="text-xs flex-shrink-0"
                  style={{
                    backgroundColor: `${getPartyColor(official.party)}15`,
                    color: getPartyColor(official.party),
                    borderColor: `${getPartyColor(official.party)}30`,
                  }}
                >
                  {official.party}
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
