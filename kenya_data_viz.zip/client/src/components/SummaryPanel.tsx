import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Download, FileText, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import TimeSeriesChart from "@/components/TimeSeriesChart";
import PoliticalTimeline from "@/components/PoliticalTimeline";

interface SummaryPanelProps {
  regionName: string;
  selectedYear: number;
  indicatorName: string;
  indicatorType: "economic" | "political";
  keyMetrics: Array<{ label: string; value: string; change?: string }>;
  dataSource: string;
  lastUpdated: string;
  showDataCaveat?: boolean;
  timeSeriesData?: Array<{ year: number; value: number }>;
  politicalOfficials?: Array<{ year: number; name: string; party: string; partyColor: string; position: string }>;
  onExportData: () => void;
  onGenerateReport: () => void;
}

export default function SummaryPanel({
  regionName,
  selectedYear,
  indicatorName,
  indicatorType,
  keyMetrics,
  dataSource,
  lastUpdated,
  showDataCaveat = false,
  timeSeriesData = [],
  politicalOfficials = [],
  onExportData,
  onGenerateReport,
}: SummaryPanelProps) {
  const [isCaveatDismissed, setIsCaveatDismissed] = useState(false);

  return (
    <div className="space-y-4">
      {/* Summary Box */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <CardTitle className="text-lg">{regionName}</CardTitle>
              <p className="text-sm text-muted-foreground">{selectedYear}</p>
            </div>
            <Badge variant="outline" className="text-xs">
              {indicatorName}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Key Statistics */}
          <div className="space-y-3">
            {keyMetrics.map((metric, index) => (
              <div key={index} className="flex items-baseline justify-between">
                <span className="text-sm text-muted-foreground">{metric.label}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-semibold">{metric.value}</span>
                  {metric.change && (
                    <span
                      className={`text-xs ${
                        metric.change.startsWith("+")
                          ? "text-green-600"
                          : metric.change.startsWith("-")
                          ? "text-red-600"
                          : "text-muted-foreground"
                      }`}
                    >
                      {metric.change}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <Separator />

          {/* Data Source */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <RefreshCw className="h-3 w-3" />
              <span>Updated {lastUpdated}</span>
            </div>
            <Badge variant="secondary" className="text-xs">
              {dataSource}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Data Caveat Alert */}
      {showDataCaveat && !isCaveatDismissed && (
        <Alert className="data-caveat relative">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-sm pr-6">
            Economic data for this level is an estimate disaggregated from County-level figures.
          </AlertDescription>
          <button
            onClick={() => setIsCaveatDismissed(true)}
            className="absolute top-2 right-2 text-warning-foreground hover:bg-warning-foreground/10 rounded p-1"
            aria-label="Dismiss"
          >
            <span className="text-xs">✕</span>
          </button>
        </Alert>
      )}

      {/* Time-Series Chart */}
      {timeSeriesData.length > 0 && (
        <Card>
          <CardContent className="pt-6">
            <TimeSeriesChart
              data={timeSeriesData}
              title="Trend Analysis (2013-Present)"
              yAxisLabel={indicatorName}
              valueFormatter={(value) => {
                if (indicatorType === "economic") {
                  if (indicatorName.includes("GCP") || indicatorName.includes("GDP")) {
                    return new Intl.NumberFormat("en-KE", {
                      style: "currency",
                      currency: "KES",
                      notation: "compact",
                      maximumFractionDigits: 1,
                    }).format(value);
                  } else if (indicatorName.includes("Population")) {
                    return new Intl.NumberFormat("en-KE", {
                      notation: "compact",
                      maximumFractionDigits: 1,
                    }).format(value);
                  } else if (indicatorName.includes("Poverty")) {
                    return `${value.toFixed(1)}%`;
                  }
                }
                return value.toLocaleString();
              }}
              onDownload={() => {
                // Download chart as PNG
                onExportData();
              }}
            />
          </CardContent>
        </Card>
      )}

      {/* Political Timeline */}
      {indicatorType === "political" && politicalOfficials.length > 0 && (
        <PoliticalTimeline
          officials={politicalOfficials}
          title="Elected Officials"
        />
      )}

      {/* Action Buttons */}
      <div className="space-y-2">
        <Button
          variant="outline"
          className="w-full justify-start gap-2"
          onClick={onExportData}
        >
          <Download className="h-4 w-4" />
          Export Data (Excel)
        </Button>
        <Button
          variant="outline"
          className="w-full justify-start gap-2"
          onClick={onGenerateReport}
        >
          <FileText className="h-4 w-4" />
          Generate Report (PDF)
        </Button>
      </div>
    </div>
  );
}
