import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import MapVisualization from "@/components/MapVisualization";
import TimeSeriesChart from "@/components/TimeSeriesChart";
import { Badge } from "@/components/ui/badge";

interface SideBySideViewProps {
  selectedYear: number;
  economicIndicator: string;
  politicalIndicator: string;
  economicData: Array<{ year: number; value: number }>;
  politicalData: Array<{ year: number; value: number }>;
  onRegionClick?: (regionCode: string, regionName: string) => void;
}

export default function SideBySideView({
  selectedYear,
  economicIndicator,
  politicalIndicator,
  economicData,
  politicalData,
  onRegionClick,
}: SideBySideViewProps) {
  return (
    <div className="flex flex-col lg:flex-row h-full gap-4 p-4 overflow-auto">
      {/* Left Panel: Economic View */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        <Card className="border-2 border-primary/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Economic Landscape</CardTitle>
              <Badge variant="default" className="bg-primary">
                Economic
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Economic Map */}
            <div className="h-80 lg:h-96 rounded-lg overflow-hidden border border-border">
              <MapVisualization
                selectedIndicator={economicIndicator}
                indicatorType="economic"
                selectedYear={selectedYear}
                onRegionClick={onRegionClick}
              />
            </div>

            {/* Economic Chart */}
            <div className="p-4 bg-muted/30 rounded-lg">
              <TimeSeriesChart
                data={economicData}
                title="Economic Trend"
                yAxisLabel="GCP (KSh)"
                valueFormatter={(value) =>
                  new Intl.NumberFormat("en-KE", {
                    style: "currency",
                    currency: "KES",
                    notation: "compact",
                    maximumFractionDigits: 1,
                  }).format(value)
                }
              />
            </div>

            {/* Economic Summary */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-foreground">KSh 120.5B</div>
                  <div className="text-sm text-muted-foreground">Current GDP</div>
                  <div className="text-xs text-green-600 mt-1">+5.2% YoY</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-foreground">36.1%</div>
                  <div className="text-sm text-muted-foreground">Poverty Rate</div>
                  <div className="text-xs text-green-600 mt-1">-1.5% YoY</div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Right Panel: Political View */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        <Card className="border-2 border-destructive/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Political Landscape</CardTitle>
              <Badge variant="destructive">Political</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Political Map */}
            <div className="h-80 lg:h-96 rounded-lg overflow-hidden border border-border">
              <MapVisualization
                selectedIndicator={politicalIndicator}
                indicatorType="political"
                selectedYear={selectedYear}
                onRegionClick={onRegionClick}
              />
            </div>

            {/* Political Chart */}
            <div className="p-4 bg-muted/30 rounded-lg">
              <TimeSeriesChart
                data={politicalData}
                title="Political Trend"
                yAxisLabel="Vote Share (%)"
                valueFormatter={(value) => `${value.toFixed(1)}%`}
              />
            </div>

            {/* Political Summary */}
            <div className="space-y-3">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">Current President</div>
                      <div className="text-lg font-semibold text-foreground mt-1">
                        William Ruto
                      </div>
                    </div>
                    <Badge
                      variant="secondary"
                      className="text-xs"
                      style={{
                        backgroundColor: "oklch(var(--party-amber) / 0.15)",
                        color: "oklch(var(--party-amber))",
                      }}
                    >
                      UDA
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Election Year</div>
                  <div className="text-2xl font-bold text-foreground mt-1">2022</div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
