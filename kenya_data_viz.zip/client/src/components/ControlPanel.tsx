import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapIcon, LayoutGrid, Table2, X } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface ControlPanelProps {
  // Geographic selection
  selectedLevel: string;
  selectedRegion: string;
  breadcrumbs: Array<{ level: string; name: string; code: string }>;
  onBreadcrumbClick: (level: string, code: string) => void;
  onRegionChange: (code: string) => void;
  
  // Indicator selection
  indicatorType: "economic" | "political";
  selectedIndicator: string;
  onIndicatorTypeChange: (type: "economic" | "political") => void;
  onIndicatorChange: (indicator: string) => void;
  
  // View mode
  viewMode: "map" | "sideBySide" | "table";
  onViewModeChange: (mode: "map" | "sideBySide" | "table") => void;
  
  // Active filters
  activeFilters: Array<{ key: string; label: string }>;
  onRemoveFilter: (key: string) => void;
}

export default function ControlPanel({
  selectedLevel,
  selectedRegion,
  breadcrumbs,
  onBreadcrumbClick,
  onRegionChange,
  indicatorType,
  selectedIndicator,
  onIndicatorTypeChange,
  onIndicatorChange,
  viewMode,
  onViewModeChange,
  activeFilters,
  onRemoveFilter,
}: ControlPanelProps) {
  const economicIndicators = [
    { value: "gcp_current_prices", label: "GCP Current Prices" },
    { value: "poverty_headcount", label: "Poverty Headcount Rate" },
    { value: "population_estimate", label: "Population Estimate" },
  ];

  const politicalIndicators = [
    { value: "presidential_vote_share", label: "Presidential Vote Share" },
    { value: "governor_party", label: "Governor Party" },
    { value: "mp_party", label: "MP Party" },
    { value: "senator_party", label: "Senator Party" },
    { value: "mca_party", label: "MCA Party" },
  ];

  return (
    <div className="space-y-6">
      {/* Geographic Selector */}
      <div className="space-y-3">
        <Label className="text-sm font-semibold">Geographic Area</Label>
        
        {/* Breadcrumb Navigation */}
        {breadcrumbs.length > 0 && (
          <div className="flex flex-wrap items-center gap-1 text-sm">
            {breadcrumbs.map((crumb, index) => (
              <div key={crumb.code} className="flex items-center gap-1">
                <button
                  onClick={() => onBreadcrumbClick(crumb.level, crumb.code)}
                  className="text-primary hover:underline focus-visible-ring rounded px-1"
                >
                  {crumb.name}
                </button>
                {index < breadcrumbs.length - 1 && (
                  <span className="text-muted-foreground">/</span>
                )}
              </div>
            ))}
          </div>
        )}
        
        {/* Region Selector */}
        <Select value={selectedRegion} onValueChange={onRegionChange}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select region" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="national">National</SelectItem>
            <SelectItem value="county-001">Nairobi County</SelectItem>
            <SelectItem value="county-002">Mombasa County</SelectItem>
            <SelectItem value="county-003">Kisumu County</SelectItem>
            {/* More regions will be loaded dynamically */}
          </SelectContent>
        </Select>
      </div>

      <Separator />

      {/* Indicator Selector */}
      <div className="space-y-3">
        <Label className="text-sm font-semibold">Indicator</Label>
        
        <Tabs value={indicatorType} onValueChange={(v) => onIndicatorTypeChange(v as "economic" | "political")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="economic">Economic</TabsTrigger>
            <TabsTrigger value="political">Political</TabsTrigger>
          </TabsList>
          
          <TabsContent value="economic" className="mt-3">
            <Select value={selectedIndicator} onValueChange={onIndicatorChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select indicator" />
              </SelectTrigger>
              <SelectContent>
                {economicIndicators.map((indicator) => (
                  <SelectItem key={indicator.value} value={indicator.value}>
                    {indicator.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </TabsContent>
          
          <TabsContent value="political" className="mt-3">
            <Select value={selectedIndicator} onValueChange={onIndicatorChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select indicator" />
              </SelectTrigger>
              <SelectContent>
                {politicalIndicators.map((indicator) => (
                  <SelectItem key={indicator.value} value={indicator.value}>
                    {indicator.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </TabsContent>
        </Tabs>
      </div>

      <Separator />

      {/* View Mode Toggle */}
      <div className="space-y-3">
        <Label className="text-sm font-semibold">View Mode</Label>
        
        <div className="grid grid-cols-3 gap-2">
          <Button
            variant={viewMode === "map" ? "default" : "outline"}
            size="sm"
            onClick={() => onViewModeChange("map")}
            className="flex flex-col items-center gap-1 h-auto py-2"
          >
            <MapIcon className="h-4 w-4" />
            <span className="text-xs">Map</span>
          </Button>
          
          <Button
            variant={viewMode === "sideBySide" ? "default" : "outline"}
            size="sm"
            onClick={() => onViewModeChange("sideBySide")}
            className="flex flex-col items-center gap-1 h-auto py-2"
          >
            <LayoutGrid className="h-4 w-4" />
            <span className="text-xs">Compare</span>
          </Button>
          
          <Button
            variant={viewMode === "table" ? "default" : "outline"}
            size="sm"
            onClick={() => onViewModeChange("table")}
            className="flex flex-col items-center gap-1 h-auto py-2"
          >
            <Table2 className="h-4 w-4" />
            <span className="text-xs">Table</span>
          </Button>
        </div>
      </div>

      <Separator />

      {/* Active Filters */}
      {activeFilters.length > 0 && (
        <div className="space-y-3">
          <Label className="text-sm font-semibold">Active Filters</Label>
          
          <div className="flex flex-wrap gap-2">
            {activeFilters.map((filter) => (
              <Badge key={filter.key} variant="secondary" className="gap-1">
                {filter.label}
                <button
                  onClick={() => onRemoveFilter(filter.key)}
                  className="ml-1 hover:bg-destructive/20 rounded-full p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
