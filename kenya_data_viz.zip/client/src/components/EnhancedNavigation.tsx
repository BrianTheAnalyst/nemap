import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Home,
  Map,
  BarChart3,
  Database,
  Settings,
  Search,
  Keyboard,
  Shield,
} from "lucide-react";

interface NavItem {
  name: string;
  path: string;
  icon: React.ReactNode;
  shortcut?: string;
  adminOnly?: boolean;
}

export default function EnhancedNavigation() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);

  const navItems: NavItem[] = [
    { name: "Home", path: "/", icon: <Home className="h-4 w-4" />, shortcut: "H" },
    { name: "Map View", path: "/", icon: <Map className="h-4 w-4" />, shortcut: "M" },
    { name: "Analytics", path: "/", icon: <BarChart3 className="h-4 w-4" />, shortcut: "A" },
    {
      name: "Admin Dashboard",
      path: "/admin",
      icon: <Shield className="h-4 w-4" />,
      shortcut: "D",
      adminOnly: true,
    },
    {
      name: "Upload Dataset",
      path: "/admin/upload",
      icon: <Database className="h-4 w-4" />,
      shortcut: "U",
      adminOnly: true,
    },
  ];

  const filteredNavItems = navItems.filter((item) => {
    if (item.adminOnly && user?.role !== "admin") return false;
    return true;
  });

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd+K or Ctrl+K to open search
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsSearchOpen(true);
      }

      // Cmd+/ or Ctrl+/ to show shortcuts
      if ((e.metaKey || e.ctrlKey) && e.key === "/") {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }

      // Alt+H for Home
      if (e.altKey && e.key === "h") {
        e.preventDefault();
        setLocation("/");
      }

      // Alt+M for Map
      if (e.altKey && e.key === "m") {
        e.preventDefault();
        setLocation("/");
      }

      // Alt+A for Analytics
      if (e.altKey && e.key === "a") {
        e.preventDefault();
        setLocation("/");
      }

      // Alt+D for Admin Dashboard (admin only)
      if (e.altKey && e.key === "d" && user?.role === "admin") {
        e.preventDefault();
        setLocation("/admin");
      }

      // Alt+U for Upload Dataset (admin only)
      if (e.altKey && e.key === "u" && user?.role === "admin") {
        e.preventDefault();
        setLocation("/admin/upload");
      }

      // Escape to close dialogs
      if (e.key === "Escape") {
        setIsSearchOpen(false);
        setIsShortcutsOpen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [user, setLocation]);

  const handleNavigate = (path: string) => {
    setLocation(path);
    setIsSearchOpen(false);
  };

  return (
    <>
      {/* Quick Search Button */}
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="gap-2"
          onClick={() => setIsSearchOpen(true)}
        >
          <Search className="h-4 w-4" />
          <span className="hidden md:inline">Quick Search</span>
          <kbd className="hidden md:inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
            <span className="text-xs">⌘</span>K
          </kbd>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsShortcutsOpen(true)}
          title="Keyboard Shortcuts"
        >
          <Keyboard className="h-4 w-4" />
        </Button>
      </div>

      {/* Command Palette / Quick Search */}
      <Dialog open={isSearchOpen} onOpenChange={setIsSearchOpen}>
        <DialogContent className="p-0 gap-0 max-w-2xl">
          <DialogHeader className="sr-only">
            <DialogTitle>Quick Navigation</DialogTitle>
          </DialogHeader>
          <Command className="rounded-lg border-none">
            <CommandInput placeholder="Search pages, features, and actions..." />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Navigation">
                {filteredNavItems.map((item) => (
                  <CommandItem
                    key={item.path}
                    onSelect={() => handleNavigate(item.path)}
                    className="cursor-pointer"
                  >
                    <div className="flex items-center gap-3 w-full">
                      {item.icon}
                      <span className="flex-1">{item.name}</span>
                      {item.shortcut && (
                        <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
                          <span className="text-xs">⌥</span>
                          {item.shortcut}
                        </kbd>
                      )}
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
              <CommandGroup heading="Quick Actions">
                <CommandItem className="cursor-pointer">
                  <div className="flex items-center gap-3">
                    <BarChart3 className="h-4 w-4" />
                    <span>Export Current View</span>
                  </div>
                </CommandItem>
                <CommandItem className="cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Settings className="h-4 w-4" />
                    <span>Change Time Range</span>
                  </div>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </Command>
        </DialogContent>
      </Dialog>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={isShortcutsOpen} onOpenChange={setIsShortcutsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Keyboard className="h-5 w-5" />
              Keyboard Shortcuts
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold mb-3 text-muted-foreground">General</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between py-2 border-b">
                  <span className="text-sm">Open quick search</span>
                  <kbd className="inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-2 font-mono text-xs font-medium">
                    <span>⌘</span>K
                  </kbd>
                </div>
                <div className="flex items-center justify-between py-2 border-b">
                  <span className="text-sm">Show keyboard shortcuts</span>
                  <kbd className="inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-2 font-mono text-xs font-medium">
                    <span>⌘</span>/
                  </kbd>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold mb-3 text-muted-foreground">Navigation</h3>
              <div className="space-y-2">
                {filteredNavItems.map((item) => (
                  <div key={item.path} className="flex items-center justify-between py-2 border-b">
                    <span className="text-sm flex items-center gap-2">
                      {item.icon}
                      {item.name}
                    </span>
                    {item.shortcut && (
                      <kbd className="inline-flex h-6 select-none items-center gap-1 rounded border bg-muted px-2 font-mono text-xs font-medium">
                        <span>⌥</span>
                        {item.shortcut}
                      </kbd>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
