import { ReactNode, useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, ChevronLeft, ChevronRight } from "lucide-react";
import EnhancedNavigation from "./EnhancedNavigation";
import { APP_TITLE } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { trpc } from "@/lib/trpc";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface VisualizationLayoutProps {
  header?: ReactNode;
  controlPanel: ReactNode;
  mainContent: ReactNode;
  summaryPanel: ReactNode;
  showControlPanel?: boolean;
  showSummaryPanel?: boolean;
}

export default function VisualizationLayout({
  header,
  controlPanel,
  mainContent,
  summaryPanel,
  showControlPanel = true,
  showSummaryPanel = true,
}: VisualizationLayoutProps) {
  const [isControlPanelOpen, setIsControlPanelOpen] = useState(true);
  const [isSummaryPanelOpen, setIsSummaryPanelOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    window.location.href = "/";
  };

  const getUserInitials = (name?: string | null) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-card border-b border-border shadow-sm">
        <div className="flex items-center justify-between h-full px-4 lg:px-6">
          {/* Left: Logo and Mobile Menu Toggle */}
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <Link href="/">
              <h1 className="text-lg lg:text-xl font-bold text-foreground cursor-pointer hover:text-primary transition-colors">
                {APP_TITLE}
              </h1>
            </Link>
          </div>

          {/* Center: Custom Header Content */}
          <div className="hidden md:flex flex-1 justify-center px-4">
            {header}
          </div>

          {/* Right: Enhanced Navigation + User Profile / Login */}
          <div className="flex items-center gap-2">
            <EnhancedNavigation />
            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getUserInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.name || "User"}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {user.role === "admin" && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/admin">Admin Dashboard</Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem onClick={handleLogout}>Log out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild variant="default" size="sm">
                <a href={getLoginUrl()}>Login</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area (below header) */}
      <div className="flex flex-1 pt-16 overflow-hidden">
        {/* Left Control Panel */}
        {showControlPanel && (
          <>
            {/* Desktop Control Panel */}
            <aside
              className={`hidden lg:flex flex-col bg-card border-r border-border transition-all duration-300 ${
                isControlPanelOpen ? "w-64" : "w-0"
              } overflow-hidden`}
            >
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h2 className="text-sm font-semibold text-foreground">Controls</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setIsControlPanelOpen(false)}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto panel-scroll p-4">{controlPanel}</div>
            </aside>

            {/* Desktop Toggle Button (when panel is closed) */}
            {!isControlPanelOpen && (
              <Button
                variant="outline"
                size="icon"
                className="hidden lg:flex absolute left-0 top-20 z-40 h-10 w-6 rounded-r-md rounded-l-none"
                onClick={() => setIsControlPanelOpen(true)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            )}

            {/* Mobile Control Panel (Drawer) */}
            {isMobileMenuOpen && (
              <div className="lg:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm">
                <aside className="fixed left-0 top-16 bottom-0 w-64 bg-card border-r border-border shadow-lg">
                  <div className="flex items-center justify-between p-4 border-b border-border">
                    <h2 className="text-sm font-semibold text-foreground">Controls</h2>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="overflow-y-auto panel-scroll p-4 h-full">{controlPanel}</div>
                </aside>
              </div>
            )}
          </>
        )}

        {/* Main Visualization Area */}
        <main className="flex-1 overflow-hidden relative">{mainContent}</main>

        {/* Right Summary Panel */}
        {showSummaryPanel && (
          <>
            {/* Desktop Summary Panel */}
            <aside
              className={`hidden lg:flex flex-col bg-card border-l border-border transition-all duration-300 ${
                isSummaryPanelOpen ? "w-96" : "w-0"
              } overflow-hidden`}
            >
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h2 className="text-sm font-semibold text-foreground">Summary & Charts</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setIsSummaryPanelOpen(false)}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto panel-scroll p-4">{summaryPanel}</div>
            </aside>

            {/* Desktop Toggle Button (when panel is closed) */}
            {!isSummaryPanelOpen && (
              <Button
                variant="outline"
                size="icon"
                className="hidden lg:flex absolute right-0 top-20 z-40 h-10 w-6 rounded-l-md rounded-r-none"
                onClick={() => setIsSummaryPanelOpen(true)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            )}

            {/* Mobile Summary Panel (Bottom Sheet - shown below map) */}
            <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-card border-t border-border max-h-[50vh] overflow-y-auto panel-scroll">
              <div className="p-4">{summaryPanel}</div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
