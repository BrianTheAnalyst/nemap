import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Calendar } from "lucide-react";

interface TimeFilterProps {
  selectedYear: number;
  yearRange: [number, number];
  onYearChange: (year: number) => void;
  onYearRangeChange: (range: [number, number]) => void;
}

const ELECTION_YEARS = [2013, 2017, 2022];
const MIN_YEAR = 2013;
const MAX_YEAR = new Date().getFullYear();

export default function TimeFilter({
  selectedYear,
  yearRange,
  onYearChange,
  onYearRangeChange,
}: TimeFilterProps) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Calendar className="h-4 w-4" />
          <span className="hidden sm:inline">
            {yearRange[0] === yearRange[1]
              ? yearRange[0]
              : `${yearRange[0]} - ${yearRange[1]}`}
          </span>
          <span className="sm:hidden">{selectedYear}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="center">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-semibold">Time Period</Label>
            <p className="text-xs text-muted-foreground">
              Select a year or range from {MIN_YEAR} to {MAX_YEAR}
            </p>
          </div>

          {/* Quick Select Election Cycles */}
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Election Cycles</Label>
            <div className="flex gap-2">
              {ELECTION_YEARS.map((year) => (
                <Button
                  key={year}
                  variant={selectedYear === year ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    onYearChange(year);
                    onYearRangeChange([year, year]);
                  }}
                  className="flex-1"
                >
                  {year}
                </Button>
              ))}
            </div>
          </div>

          {/* Year Range Slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground">Year Range</Label>
              <span className="text-xs font-medium">
                {yearRange[0]} - {yearRange[1]}
              </span>
            </div>
            <Slider
              min={MIN_YEAR}
              max={MAX_YEAR}
              step={1}
              value={yearRange}
              onValueChange={(value) => {
                const newRange: [number, number] = [value[0], value[1]];
                onYearRangeChange(newRange);
                // Set selected year to the end of the range
                onYearChange(value[1]);
              }}
              className="w-full"
            />
          </div>

          {/* Single Year Selector */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground">Current Year</Label>
              <span className="text-xs font-medium">{selectedYear}</span>
            </div>
            <Slider
              min={MIN_YEAR}
              max={MAX_YEAR}
              step={1}
              value={[selectedYear]}
              onValueChange={(value) => onYearChange(value[0])}
              className="w-full"
            />
          </div>

          {/* All Time Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onYearRangeChange([MIN_YEAR, MAX_YEAR]);
              onYearChange(MAX_YEAR);
            }}
            className="w-full"
          >
            View All Time ({MIN_YEAR} - {MAX_YEAR})
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
