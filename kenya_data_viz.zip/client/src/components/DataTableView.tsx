import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowUpDown, Download, Copy, Search } from "lucide-react";
import { toast } from "sonner";

interface DataRow {
  region: string;
  year: number;
  economicValue: string;
  politicalValue: string;
  dataSource: string;
  notes?: string;
}

interface DataTableViewProps {
  data: DataRow[];
  onExport?: () => void;
}

type SortField = "region" | "year" | "economicValue" | "politicalValue";
type SortDirection = "asc" | "desc";

export default function DataTableView({ data, onExport }: DataTableViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<SortField>("year");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const handleCopyToClipboard = () => {
    const csvContent = [
      ["Region", "Year", "Economic Value", "Political Value", "Data Source", "Notes"].join(","),
      ...filteredAndSortedData.map((row) =>
        [
          row.region,
          row.year,
          row.economicValue,
          row.politicalValue,
          row.dataSource,
          row.notes || "",
        ].join(",")
      ),
    ].join("\n");

    navigator.clipboard.writeText(csvContent);
    toast.success("Data copied to clipboard");
  };

  // Filter data based on search query
  const filteredData = data.filter((row) => {
    const query = searchQuery.toLowerCase();
    return (
      row.region.toLowerCase().includes(query) ||
      row.year.toString().includes(query) ||
      row.economicValue.toLowerCase().includes(query) ||
      row.politicalValue.toLowerCase().includes(query) ||
      row.dataSource.toLowerCase().includes(query)
    );
  });

  // Sort filtered data
  const filteredAndSortedData = [...filteredData].sort((a, b) => {
    let aValue: string | number = a[sortField];
    let bValue: string | number = b[sortField];

    if (sortField === "year") {
      aValue = a.year;
      bValue = b.year;
    }

    if (typeof aValue === "string" && typeof bValue === "string") {
      return sortDirection === "asc"
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }

    return sortDirection === "asc"
      ? (aValue as number) - (bValue as number)
      : (bValue as number) - (aValue as number);
  });

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-4 p-4 border-b border-border">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search regions, years, values..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Badge variant="secondary" className="text-xs">
            {filteredAndSortedData.length} rows
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleCopyToClipboard}>
            <Copy className="h-4 w-4 mr-2" />
            Copy
          </Button>
          {onExport && (
            <Button variant="outline" size="sm" onClick={onExport}>
              <Download className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <Table>
          <TableHeader className="sticky top-0 bg-card z-10">
            <TableRow>
              <TableHead>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("region")}
                  className="h-8 gap-1 font-semibold"
                >
                  Region
                  <ArrowUpDown className="h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("year")}
                  className="h-8 gap-1 font-semibold"
                >
                  Year
                  <ArrowUpDown className="h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("economicValue")}
                  className="h-8 gap-1 font-semibold"
                >
                  Economic Indicator
                  <ArrowUpDown className="h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort("politicalValue")}
                  className="h-8 gap-1 font-semibold"
                >
                  Political Indicator
                  <ArrowUpDown className="h-3 w-3" />
                </Button>
              </TableHead>
              <TableHead>Data Source</TableHead>
              <TableHead>Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAndSortedData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No data found
                </TableCell>
              </TableRow>
            ) : (
              filteredAndSortedData.map((row, index) => (
                <TableRow key={index} className="hover:bg-muted/50">
                  <TableCell className="font-medium">{row.region}</TableCell>
                  <TableCell>{row.year}</TableCell>
                  <TableCell>{row.economicValue}</TableCell>
                  <TableCell>{row.politicalValue}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="text-xs">
                      {row.dataSource}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {row.notes || "-"}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
