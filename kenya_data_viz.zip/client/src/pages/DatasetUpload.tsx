import { useState, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import DataPreview from "@/components/DataPreview";
import { trpc } from "@/lib/trpc";

type DatasetType = "economic" | "political" | "administrative" | "geojson";

interface ValidationError {
  row: number;
  column: string;
  message: string;
  severity: "error" | "warning";
}

interface ParsedData {
  headers: string[];
  rows: any[];
  totalRows: number;
}

export default function DatasetUpload() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [datasetType, setDatasetType] = useState<DatasetType>("economic");
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedData, setParsedData] = useState<ParsedData | null>(null);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [validationStatus, setValidationStatus] = useState<"idle" | "validating" | "success" | "error">("idle");

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  }, []);

  const handleFileSelect = (selectedFile: File) => {
    const validExtensions = [".csv", ".xlsx", ".xls", ".geojson", ".json"];
    const fileExtension = selectedFile.name.toLowerCase().match(/\.[^.]+$/)?.[0];

    if (!fileExtension || !validExtensions.includes(fileExtension)) {
      toast.error("Invalid file type. Please upload CSV, Excel, or GeoJSON files.");
      return;
    }

    setFile(selectedFile);
    setParsedData(null);
    setValidationErrors([]);
    setValidationStatus("idle");
    toast.success(`File "${selectedFile.name}" loaded successfully`);
  };

  const parseFile = async () => {
    if (!file) {
      toast.error("Please select a file first");
      return;
    }

    setIsProcessing(true);
    setValidationStatus("validating");

    try {
      const fileExtension = file.name.toLowerCase().match(/\.[^.]+$/)?.[0];

      if (fileExtension === ".csv") {
        // Parse CSV
        Papa.parse(file, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            const headers = results.meta.fields || [];
            const rows = results.data;

            setParsedData({
              headers,
              rows,
              totalRows: rows.length,
            });

            validateData(headers, rows);
            setIsProcessing(false);
          },
          error: (error) => {
            toast.error(`CSV parsing error: ${error.message}`);
            setIsProcessing(false);
            setValidationStatus("error");
          },
        });
      } else if (fileExtension === ".xlsx" || fileExtension === ".xls") {
        // Parse Excel
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

        if (jsonData.length === 0) {
          toast.error("Excel file is empty");
          setIsProcessing(false);
          setValidationStatus("error");
          return;
        }

        const headers = jsonData[0].map(String);
        const rows = jsonData.slice(1).map((row) => {
          const obj: any = {};
          headers.forEach((header, index) => {
            obj[header] = row[index];
          });
          return obj;
        });

        setParsedData({
          headers,
          rows,
          totalRows: rows.length,
        });

        validateData(headers, rows);
        setIsProcessing(false);
      } else if (fileExtension === ".geojson" || fileExtension === ".json") {
        // Parse GeoJSON
        const text = await file.text();
        const geojson = JSON.parse(text);

        if (geojson.type !== "FeatureCollection") {
          toast.error("Invalid GeoJSON format. Expected FeatureCollection.");
          setIsProcessing(false);
          setValidationStatus("error");
          return;
        }

        setParsedData({
          headers: ["Feature Type", "Properties", "Geometry"],
          rows: geojson.features.map((feature: any, index: number) => ({
            index: index + 1,
            type: feature.type,
            properties: JSON.stringify(feature.properties),
            geometry: feature.geometry.type,
          })),
          totalRows: geojson.features.length,
        });

        validateGeoJSON(geojson);
        setIsProcessing(false);
      }
    } catch (error: any) {
      toast.error(`File parsing error: ${error.message}`);
      setIsProcessing(false);
      setValidationStatus("error");
    }
  };

  const validateData = (headers: string[], rows: any[]) => {
    const errors: ValidationError[] = [];

    // Define expected schemas for each dataset type
    const schemas: Record<DatasetType, string[]> = {
      economic: ["county_name", "year", "gcp_current_prices", "poverty_rate", "population"],
      political: ["county_name", "election_year", "governor_name", "party", "vote_share"],
      administrative: ["level_type", "name", "parent_name", "code"],
      geojson: [],
    };

    const expectedHeaders = schemas[datasetType];

    // Check for missing required columns
    if (expectedHeaders.length > 0) {
      expectedHeaders.forEach((requiredHeader) => {
        if (!headers.includes(requiredHeader)) {
          errors.push({
            row: 0,
            column: requiredHeader,
            message: `Missing required column: ${requiredHeader}`,
            severity: "error",
          });
        }
      });
    }

    // Validate each row
    rows.forEach((row, index) => {
      // Check for missing values in required columns
      expectedHeaders.forEach((header) => {
        if (!row[header] || row[header] === "") {
          errors.push({
            row: index + 1,
            column: header,
            message: `Missing value in required column`,
            severity: "error",
          });
        }
      });

      // Type-specific validations
      if (datasetType === "economic" || datasetType === "political") {
        // Validate year format
        if (row.year && !/^\d{4}$/.test(String(row.year))) {
          errors.push({
            row: index + 1,
            column: "year",
            message: `Invalid year format: ${row.year}. Expected YYYY format.`,
            severity: "error",
          });
        }

        // Validate numeric values
        if (datasetType === "economic" && row.value && isNaN(Number(row.value))) {
          errors.push({
            row: index + 1,
            column: "value",
            message: `Invalid numeric value: ${row.value}`,
            severity: "error",
          });
        }

        if (datasetType === "political" && row.votes && isNaN(Number(row.votes))) {
          errors.push({
            row: index + 1,
            column: "votes",
            message: `Invalid numeric value: ${row.votes}`,
            severity: "error",
          });
        }
      }
    });

    setValidationErrors(errors);
    setValidationStatus(errors.filter((e) => e.severity === "error").length > 0 ? "error" : "success");

    if (errors.length === 0) {
      toast.success("Data validation passed! No errors found.");
    } else {
      const errorCount = errors.filter((e) => e.severity === "error").length;
      const warningCount = errors.filter((e) => e.severity === "warning").length;
      toast.error(`Validation found ${errorCount} errors and ${warningCount} warnings`);
    }
  };

  const validateGeoJSON = (geojson: any) => {
    const errors: ValidationError[] = [];

    geojson.features.forEach((feature: any, index: number) => {
      if (!feature.properties || Object.keys(feature.properties).length === 0) {
        errors.push({
          row: index + 1,
          column: "properties",
          message: "Feature has no properties",
          severity: "warning",
        });
      }

      if (!feature.geometry || !feature.geometry.type) {
        errors.push({
          row: index + 1,
          column: "geometry",
          message: "Invalid or missing geometry",
          severity: "error",
        });
      }
    });

    setValidationErrors(errors);
    setValidationStatus(errors.filter((e) => e.severity === "error").length > 0 ? "error" : "success");
  };

  const importEconomicMutation = trpc.dataset.importEconomicData.useMutation();
  const importPoliticalMutation = trpc.dataset.importPoliticalData.useMutation();
  const importAdministrativeMutation = trpc.dataset.importAdministrativeData.useMutation();
  const importGeoJSONMutation = trpc.dataset.importGeoJSON.useMutation();

  // Check if user is admin - must be after all hooks
  if (!user || user.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              You do not have permission to upload datasets.
            </p>
            <Button onClick={() => setLocation("/admin")} className="w-full">
              Return to Admin Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const transformEconomicData = (rows: any[]) => {
    // Transform wide format CSV to long format for backend
    const transformed: any[] = [];
    
    rows.forEach((row) => {
      const regionCode = row.county_name || row.region_code;
      const year = parseInt(row.year);
      
      // Transform each indicator column into a separate row
      if (row.gcp_current_prices) {
        transformed.push({
          region_code: regionCode,
          year: year,
          indicator: "gcp_current_prices",
          value: parseFloat(row.gcp_current_prices),
        });
      }
      if (row.poverty_rate) {
        transformed.push({
          region_code: regionCode,
          year: year,
          indicator: "poverty_headcount",
          value: parseFloat(row.poverty_rate),
        });
      }
      if (row.population) {
        transformed.push({
          region_code: regionCode,
          year: year,
          indicator: "population_estimate",
          value: parseFloat(row.population),
        });
      }
    });
    
    return transformed;
  };

  const handleImport = async () => {
    if (!parsedData || validationStatus === "error") {
      toast.error("Cannot import data with validation errors");
      return;
    }

    setIsProcessing(true);
    toast.info("Importing data to database...");

    try {
      if (datasetType === "economic") {
        const transformedData = transformEconomicData(parsedData.rows);
        const result = await importEconomicMutation.mutateAsync({
          data: transformedData,
        });
        toast.success(result.message);
      } else if (datasetType === "political") {
        const result = await importPoliticalMutation.mutateAsync({
          data: parsedData.rows,
        });
        toast.success(result.message);
      } else if (datasetType === "administrative") {
        const result = await importAdministrativeMutation.mutateAsync({
          data: parsedData.rows,
        });
        toast.success(result.message);
      } else if (datasetType === "geojson") {
        const result = await importGeoJSONMutation.mutateAsync({
          features: parsedData.rows,
        });
        toast.success(result.message);
      }

      setTimeout(() => {
        setLocation("/admin");
      }, 1500);
    } catch (error: any) {
      toast.error(`Import failed: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dataset Upload & Validation</h1>
            <p className="text-muted-foreground mt-1">
              Upload and validate datasets before importing to the database
            </p>
          </div>
          <Button variant="outline" onClick={() => setLocation("/admin")}>
            Back to Admin
          </Button>
        </div>

        {/* Dataset Type Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Step 1: Select Dataset Type</CardTitle>
            <CardDescription>
              Choose the type of data you're uploading to apply the correct validation rules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="dataset-type">Dataset Type</Label>
              <Select value={datasetType} onValueChange={(value) => setDatasetType(value as DatasetType)}>
                <SelectTrigger id="dataset-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="economic">Economic Indicators (GCP, Poverty, Population)</SelectItem>
                  <SelectItem value="political">Political Data (Elections, Officials)</SelectItem>
                  <SelectItem value="administrative">Administrative Boundaries (Metadata)</SelectItem>
                  <SelectItem value="geojson">GeoJSON Boundaries (Geometry)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* File Upload */}
        <Card>
          <CardHeader>
            <CardTitle>Step 2: Upload File</CardTitle>
            <CardDescription>
              Drag and drop your file or click to browse. Supported formats: CSV, Excel (.xlsx, .xls), GeoJSON
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50 hover:bg-muted/50"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input
                type="file"
                id="file-upload"
                className="hidden"
                accept=".csv,.xlsx,.xls,.geojson,.json"
                onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <div className="flex flex-col items-center gap-4">
                  {file ? (
                    <>
                      <FileSpreadsheet className="h-16 w-16 text-primary" />
                      <div>
                        <p className="text-lg font-semibold text-foreground">{file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(file.size / 1024).toFixed(2)} KB
                        </p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setFile(null)}>
                        Remove File
                      </Button>
                    </>
                  ) : (
                    <>
                      <Upload className="h-16 w-16 text-muted-foreground" />
                      <div>
                        <p className="text-lg font-semibold text-foreground">
                          Drop your file here or click to browse
                        </p>
                        <p className="text-sm text-muted-foreground">
                          CSV, Excel, or GeoJSON files up to 50MB
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </label>
            </div>

            {file && (
              <div className="mt-4">
                <Button onClick={parseFile} disabled={isProcessing} className="w-full">
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Parse & Validate Data
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Validation Results */}
        {validationStatus !== "idle" && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Step 3: Validation Results</CardTitle>
                {validationStatus === "success" && (
                  <Badge variant="default" className="bg-green-600">
                    <CheckCircle2 className="h-4 w-4 mr-1" />
                    Passed
                  </Badge>
                )}
                {validationStatus === "error" && (
                  <Badge variant="destructive">
                    <XCircle className="h-4 w-4 mr-1" />
                    Failed
                  </Badge>
                )}
                {validationStatus === "validating" && (
                  <Badge variant="secondary">
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    Validating...
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {parsedData && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Found <strong>{parsedData.totalRows}</strong> rows with{" "}
                    <strong>{parsedData.headers.length}</strong> columns
                  </AlertDescription>
                </Alert>
              )}

              {validationErrors.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold">
                    Errors & Warnings ({validationErrors.length})
                  </h3>
                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {validationErrors.slice(0, 50).map((error, index) => (
                      <Alert key={index} variant={error.severity === "error" ? "destructive" : "default"}>
                        <AlertDescription className="text-xs">
                          <span className="font-semibold">
                            Row {error.row}, Column "{error.column}":
                          </span>{" "}
                          {error.message}
                        </AlertDescription>
                      </Alert>
                    ))}
                    {validationErrors.length > 50 && (
                      <p className="text-xs text-muted-foreground text-center">
                        ... and {validationErrors.length - 50} more errors
                      </p>
                    )}
                  </div>
                </div>
              )}

              {validationStatus === "success" && (
                <Button onClick={handleImport} className="w-full" size="lg">
                  <Upload className="h-4 w-4 mr-2" />
                  Import {parsedData?.totalRows} Rows to Database
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Data Preview */}
        {parsedData && (
          <Card>
            <CardHeader>
              <CardTitle>Data Preview</CardTitle>
              <CardDescription>
                Review the parsed data before importing to the database
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataPreview
                headers={parsedData.headers}
                rows={parsedData.rows}
                totalRows={parsedData.totalRows}
              />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
