import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle, Loader2, Play, Upload, FileText, Search, Database } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedSource, setSelectedSource] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isRunning, setIsRunning] = useState(false);

  // Check if user is admin
  if (!user || user.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              You do not have permission to access the admin dashboard.
            </p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Sample ETL data sources
  const dataSources = [
    {
      name: "KNBS GCP Data",
      lastRun: "2 hours ago",
      status: "success" as const,
      recordsProcessed: 47,
      nextRun: "In 22 hours",
    },
    {
      name: "IEBC Election Results",
      lastRun: "5 hours ago",
      status: "success" as const,
      recordsProcessed: 1450,
      nextRun: "In 19 hours",
    },
    {
      name: "GIS Boundaries",
      lastRun: "1 day ago",
      status: "failure" as const,
      recordsProcessed: 0,
      nextRun: "Manual",
      error: "Connection timeout",
    },
    {
      name: "Population Estimates",
      lastRun: "3 hours ago",
      status: "success" as const,
      recordsProcessed: 290,
      nextRun: "In 21 hours",
    },
    {
      name: "Poverty Indicators",
      lastRun: "Currently running",
      status: "in_progress" as const,
      recordsProcessed: 125,
      nextRun: "N/A",
    },
  ];

  // Sample job logs
  const jobLogs = [
    {
      timestamp: "2024-01-15 10:30:00",
      jobName: "KNBS GCP Data",
      status: "success" as const,
      recordsProcessed: 47,
      duration: "2.3s",
    },
    {
      timestamp: "2024-01-15 09:15:00",
      jobName: "IEBC Election Results",
      status: "success" as const,
      recordsProcessed: 1450,
      duration: "15.7s",
    },
    {
      timestamp: "2024-01-14 22:00:00",
      jobName: "GIS Boundaries",
      status: "failure" as const,
      recordsProcessed: 0,
      duration: "30.0s",
      error: "Connection timeout to external API",
    },
    {
      timestamp: "2024-01-14 20:45:00",
      jobName: "Population Estimates",
      status: "success" as const,
      recordsProcessed: 290,
      duration: "5.1s",
    },
    {
      timestamp: "2024-01-14 18:30:00",
      jobName: "KNBS GCP Data",
      status: "success" as const,
      recordsProcessed: 47,
      duration: "2.1s",
    },
  ];

  const getStatusIcon = (status: "success" | "failure" | "in_progress") => {
    switch (status) {
      case "success":
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case "failure":
        return <XCircle className="h-5 w-5 text-red-600" />;
      case "in_progress":
        return <Loader2 className="h-5 w-5 text-blue-600 animate-spin" />;
    }
  };

  const getStatusBadge = (status: "success" | "failure" | "in_progress") => {
    switch (status) {
      case "success":
        return (
          <Badge variant="default" className="bg-green-600">
            Success
          </Badge>
        );
      case "failure":
        return <Badge variant="destructive">Failure</Badge>;
      case "in_progress":
        return (
          <Badge variant="default" className="bg-blue-600">
            Running
          </Badge>
        );
    }
  };

  const handleManualRun = () => {
    if (!selectedSource) {
      toast.error("Please select a data source");
      return;
    }
    setIsRunning(true);
    toast.success(`Starting ETL job for ${selectedSource}...`);
    setTimeout(() => {
      setIsRunning(false);
      toast.success("ETL job completed successfully");
    }, 3000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast.success(`Uploading ${file.name} to S3...`);
      setTimeout(() => {
        toast.success("File uploaded successfully");
      }, 2000);
    }
  };

  const filteredLogs = jobLogs.filter((log) => {
    const query = searchQuery.toLowerCase();
    return (
      log.jobName.toLowerCase().includes(query) ||
      log.status.toLowerCase().includes(query) ||
      log.timestamp.includes(query)
    );
  });

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              ETL and Data Ingestion Status
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={() => setLocation("/admin/upload")}>
              <Database className="h-4 w-4 mr-2" />
              Upload Dataset
            </Button>
            <Button variant="outline" onClick={() => setLocation("/")}>
              Back to Visualization
            </Button>
          </div>
        </div>

        {/* Data Sources Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Data Sources</CardTitle>
              <div className="flex items-center gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Play className="h-4 w-4 mr-2" />
                      Trigger Manual Run
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Trigger Manual ETL Run</DialogTitle>
                      <DialogDescription>
                        Select a data source to run the ETL job manually.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="source">Data Source</Label>
                        <Select value={selectedSource} onValueChange={setSelectedSource}>
                          <SelectTrigger id="source">
                            <SelectValue placeholder="Select data source" />
                          </SelectTrigger>
                          <SelectContent>
                            {dataSources.map((source) => (
                              <SelectItem key={source.name} value={source.name}>
                                {source.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Button
                        onClick={handleManualRun}
                        disabled={isRunning}
                        className="w-full"
                      >
                        {isRunning ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Running...
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Start Job
                          </>
                        )}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload File
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upload New File</DialogTitle>
                      <DialogDescription>
                        Upload a CSV or Excel file to S3 for processing.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="file">File</Label>
                        <Input
                          id="file"
                          type="file"
                          accept=".csv,.xlsx,.xls"
                          onChange={handleFileUpload}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Supported formats: CSV, Excel (.xlsx, .xls)
                      </p>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Data Source</TableHead>
                  <TableHead>Last Run</TableHead>
                  <TableHead>Records Processed</TableHead>
                  <TableHead>Next Scheduled Run</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dataSources.map((source) => (
                  <TableRow key={source.name}>
                    <TableCell>{getStatusIcon(source.status)}</TableCell>
                    <TableCell className="font-medium">{source.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {source.lastRun}
                    </TableCell>
                    <TableCell>{source.recordsProcessed.toLocaleString()}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {source.nextRun}
                    </TableCell>
                    <TableCell>
                      {source.error && (
                        <span className="text-xs text-red-600">{source.error}</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Job Logs */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Job Logs</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search logs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 w-64"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  Export Logs
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Job Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Records Processed</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Error Message</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No logs found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredLogs.map((log, index) => (
                    <TableRow key={index}>
                      <TableCell className="text-sm text-muted-foreground">
                        {log.timestamp}
                      </TableCell>
                      <TableCell className="font-medium">{log.jobName}</TableCell>
                      <TableCell>{getStatusBadge(log.status)}</TableCell>
                      <TableCell>{log.recordsProcessed.toLocaleString()}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {log.duration}
                      </TableCell>
                      <TableCell>
                        {log.error && (
                          <span className="text-xs text-red-600">{log.error}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
