import { useState } from "react";
import VisualizationLayout from "@/components/VisualizationLayout";
import ControlPanel from "@/components/ControlPanel";
import SummaryPanel from "@/components/SummaryPanel";
import TimeFilter from "@/components/TimeFilter";
import MapVisualization from "@/components/MapVisualization";
import SideBySideView from "@/components/SideBySideView";
import DataTableView from "@/components/DataTableView";
import { toast } from "sonner";

export default function Home() {
  // Geographic state
  const [selectedLevel, setSelectedLevel] = useState("national");
  const [selectedRegion, setSelectedRegion] = useState("national");
  const [breadcrumbs, setBreadcrumbs] = useState([
    { level: "national", name: "National", code: "national" },
  ]);

  // Indicator state
  const [indicatorType, setIndicatorType] = useState<"economic" | "political">("economic");
  const [selectedIndicator, setSelectedIndicator] = useState("gcp_current_prices");

  // View mode state
  const [viewMode, setViewMode] = useState<"map" | "sideBySide" | "table">("map");

  // Time filter state
  const [selectedYear, setSelectedYear] = useState(2022);
  const [yearRange, setYearRange] = useState<[number, number]>([2013, 2022]);

  // Active filters
  const [activeFilters, setActiveFilters] = useState<Array<{ key: string; label: string }>>([]);

  const handleBreadcrumbClick = (level: string, code: string) => {
    // Navigate back to a previous level
    const index = breadcrumbs.findIndex((b) => b.code === code);
    if (index !== -1) {
      setBreadcrumbs(breadcrumbs.slice(0, index + 1));
      setSelectedLevel(level);
      setSelectedRegion(code);
    }
  };

  const handleRegionChange = (code: string) => {
    setSelectedRegion(code);
    // In a real implementation, this would trigger a drill-down
    // and update breadcrumbs accordingly
  };

  const handleRemoveFilter = (key: string) => {
    setActiveFilters(activeFilters.filter((f) => f.key !== key));
  };

  const handleExportData = () => {
    toast.success("Exporting data to Excel...");
    // Will be implemented with actual API call
  };

  const handleGenerateReport = () => {
    toast.success("Generating PDF report...");
    // Will be implemented with actual API call
  };

  // Mock data for summary panel
  const keyMetrics = [
    { label: "National GDP", value: "KSh 120.5B", change: "+5.2%" },
    { label: "Population", value: "52.2M", change: "+2.1%" },
    { label: "Poverty Rate", value: "36.1%", change: "-1.5%" },
  ];

  // Sample time-series data for charts
  const economicTimeSeriesData = [
    { year: 2013, value: 95000000000 },
    { year: 2014, value: 98500000000 },
    { year: 2015, value: 102000000000 },
    { year: 2016, value: 106500000000 },
    { year: 2017, value: 110000000000 },
    { year: 2018, value: 113500000000 },
    { year: 2019, value: 116800000000 },
    { year: 2020, value: 115200000000 },
    { year: 2021, value: 118400000000 },
    { year: 2022, value: 120500000000 },
  ];

  // Sample political officials data
  const politicalOfficials = [
    { year: 2013, name: "Uhuru Kenyatta", party: "Jubilee", partyColor: "blue", position: "President" },
    { year: 2017, name: "Uhuru Kenyatta", party: "Jubilee", partyColor: "blue", position: "President" },
    { year: 2022, name: "William Ruto", party: "UDA", partyColor: "amber", position: "President" },
  ];

  // Sample political time-series data
  const politicalTimeSeriesData = [
    { year: 2013, value: 50.5 },
    { year: 2017, value: 54.3 },
    { year: 2022, value: 50.8 },
  ];

  // Sample data for table view
  const tableData = [
    {
      region: "Kenya (National)",
      year: 2022,
      economicValue: "KSh 120.5B",
      politicalValue: "William Ruto (UDA) - 50.8%",
      dataSource: "KNBS/IEBC",
      notes: "Latest data",
    },
    {
      region: "Nairobi County",
      year: 2022,
      economicValue: "KSh 1.2T",
      politicalValue: "Sakaja Johnson (Independent)",
      dataSource: "KNBS/IEBC",
    },
    {
      region: "Mombasa County",
      year: 2022,
      economicValue: "KSh 450B",
      politicalValue: "Abdulswamad Nassir (ODM)",
      dataSource: "KNBS/IEBC",
    },
    {
      region: "Kisumu County",
      year: 2022,
      economicValue: "KSh 380B",
      politicalValue: "Anyang' Nyong'o (ODM)",
      dataSource: "KNBS/IEBC",
    },
    {
      region: "Nakuru County",
      year: 2022,
      economicValue: "KSh 520B",
      politicalValue: "Susan Kihika (UDA)",
      dataSource: "KNBS/IEBC",
    },
  ];

  return (
    <VisualizationLayout
      header={
        <TimeFilter
          selectedYear={selectedYear}
          yearRange={yearRange}
          onYearChange={setSelectedYear}
          onYearRangeChange={setYearRange}
        />
      }
      controlPanel={
        <ControlPanel
          selectedLevel={selectedLevel}
          selectedRegion={selectedRegion}
          breadcrumbs={breadcrumbs}
          onBreadcrumbClick={handleBreadcrumbClick}
          onRegionChange={handleRegionChange}
          indicatorType={indicatorType}
          selectedIndicator={selectedIndicator}
          onIndicatorTypeChange={setIndicatorType}
          onIndicatorChange={setSelectedIndicator}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          activeFilters={activeFilters}
          onRemoveFilter={handleRemoveFilter}
        />
      }
      mainContent={
        viewMode === "map" ? (
          <MapVisualization
            selectedIndicator={selectedIndicator}
            indicatorType={indicatorType}
            selectedYear={selectedYear}
            onRegionClick={(code, name) => {
              // Handle drill-down
              setBreadcrumbs([...breadcrumbs, { level: "county", name, code }]);
              setSelectedLevel("county");
              setSelectedRegion(code);
              toast.success(`Drilling down to ${name}`);
            }}
          />
        ) : viewMode === "sideBySide" ? (
          <SideBySideView
            selectedYear={selectedYear}
            economicIndicator="gcp_current_prices"
            politicalIndicator="presidential_vote_share"
            economicData={economicTimeSeriesData}
            politicalData={politicalTimeSeriesData}
            onRegionClick={(code, name) => {
              setBreadcrumbs([...breadcrumbs, { level: "county", name, code }]);
              setSelectedLevel("county");
              setSelectedRegion(code);
              toast.success(`Drilling down to ${name}`);
            }}
          />
        ) : (
          <DataTableView data={tableData} onExport={handleExportData} />
        )
      }
      summaryPanel={
        <SummaryPanel
          regionName="Kenya (National)"
          selectedYear={selectedYear}
          indicatorName={
            indicatorType === "economic" ? "GCP Current Prices" : "Presidential Vote Share"
          }
          indicatorType={indicatorType}
          keyMetrics={keyMetrics}
          dataSource="KNBS"
          lastUpdated="2 hours ago"
          showDataCaveat={selectedLevel !== "national" && selectedLevel !== "county"}
          timeSeriesData={indicatorType === "economic" ? economicTimeSeriesData : []}
          politicalOfficials={indicatorType === "political" ? politicalOfficials : []}
          onExportData={handleExportData}
          onGenerateReport={handleGenerateReport}
        />
      }
    />
  );
}
