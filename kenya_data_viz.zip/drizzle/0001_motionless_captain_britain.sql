CREATE TABLE `administrative_levels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`level` enum('national','county','subcounty','ward') NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(255) NOT NULL,
	`parentCode` varchar(32),
	`geoJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `administrative_levels_id` PRIMARY KEY(`id`),
	CONSTRAINT `administrative_levels_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `economic_indicators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`regionCode` varchar(32) NOT NULL,
	`year` int NOT NULL,
	`indicatorType` enum('gcp_current_prices','poverty_headcount','population_estimate') NOT NULL,
	`value` varchar(255) NOT NULL,
	`isEstimated` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `economic_indicators_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `etl_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobName` varchar(255) NOT NULL,
	`status` enum('success','failure','in_progress') NOT NULL,
	`recordsProcessed` int NOT NULL DEFAULT 0,
	`errorMessage` text,
	`startedAt` timestamp NOT NULL,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `etl_jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `political_indicators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`regionCode` varchar(32) NOT NULL,
	`year` int NOT NULL,
	`indicatorType` enum('presidential_vote_share','governor_party','mp_party','senator_party','mca_party') NOT NULL,
	`value` varchar(255) NOT NULL,
	`officialName` varchar(255),
	`partyName` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `political_indicators_id` PRIMARY KEY(`id`)
);
