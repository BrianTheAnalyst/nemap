import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Geographic administrative boundaries cache
export const administrativeLevels = mysqlTable("administrative_levels", {
  id: int("id").autoincrement().primaryKey(),
  level: mysqlEnum("level", ["national", "county", "subcounty", "ward"]).notNull(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  parentCode: varchar("parentCode", { length: 32 }),
  geoJson: text("geoJson"), // Store GeoJSON boundary data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdministrativeLevel = typeof administrativeLevels.$inferSelect;
export type InsertAdministrativeLevel = typeof administrativeLevels.$inferInsert;

// Economic indicators cache
export const economicIndicators = mysqlTable("economic_indicators", {
  id: int("id").autoincrement().primaryKey(),
  regionCode: varchar("regionCode", { length: 32 }).notNull(),
  year: int("year").notNull(),
  indicatorType: mysqlEnum("indicatorType", ["gcp_current_prices", "poverty_headcount", "population_estimate"]).notNull(),
  value: varchar("value", { length: 255 }).notNull(), // Store as string to handle various formats
  isEstimated: int("isEstimated").default(0).notNull(), // Boolean flag for disaggregated data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EconomicIndicator = typeof economicIndicators.$inferSelect;
export type InsertEconomicIndicator = typeof economicIndicators.$inferInsert;

// Political indicators cache
export const politicalIndicators = mysqlTable("political_indicators", {
  id: int("id").autoincrement().primaryKey(),
  regionCode: varchar("regionCode", { length: 32 }).notNull(),
  year: int("year").notNull(),
  indicatorType: mysqlEnum("indicatorType", ["presidential_vote_share", "governor_party", "mp_party", "senator_party", "mca_party"]).notNull(),
  value: varchar("value", { length: 255 }).notNull(),
  officialName: varchar("officialName", { length: 255 }),
  partyName: varchar("partyName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PoliticalIndicator = typeof politicalIndicators.$inferSelect;
export type InsertPoliticalIndicator = typeof politicalIndicators.$inferInsert;

// ETL job logs for admin dashboard
export const etlJobs = mysqlTable("etl_jobs", {
  id: int("id").autoincrement().primaryKey(),
  jobName: varchar("jobName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["success", "failure", "in_progress"]).notNull(),
  recordsProcessed: int("recordsProcessed").default(0).notNull(),
  errorMessage: text("errorMessage"),
  startedAt: timestamp("startedAt").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ETLJob = typeof etlJobs.$inferSelect;
export type InsertETLJob = typeof etlJobs.$inferInsert;