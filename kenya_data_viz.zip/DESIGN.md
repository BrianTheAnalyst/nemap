# Design System & Architecture Decisions

## Technology Stack

**Note:** The original specification requested Vue.js, but this project uses **React 19** as provided by the Manus template. React provides equivalent capabilities for building the interactive visualization system with Mapbox GL JS and D3.js.

### Core Technologies
- **Frontend Framework:** React 19 with TypeScript
- **Styling:** Tailwind CSS 4 with shadcn/ui components
- **Mapping:** Mapbox GL JS for interactive choropleth maps
- **Charts:** D3.js for time-series visualizations
- **Backend:** tRPC 11 + Express 4 (API proxy to Laravel backend)
- **Database:** MySQL/TiDB (for caching and user management)
- **Authentication:** Manus OAuth with role-based access control

## Color Palette

### Primary Colors (Economic Data)
- **Prosperity Scale:** Yellow to Green gradient (`#FEF3C7` → `#10B981`)
- **Poverty Scale:** Red to Orange gradient (`#DC2626` → `#F97316`)

### Secondary Colors (Political Data)
- **Party Colors:** Categorical palette for political parties
  - Party A: `#3B82F6` (Blue)
  - Party B: `#EF4444` (Red)
  - Party C: `#10B981` (Green)
  - Party D: `#F59E0B` (Amber)
  - Neutral: `#6B7280` (Gray)

### UI Colors
- **Background:** `#FFFFFF` (Light mode primary)
- **Surface:** `#F9FAFB` (Light gray for panels)
- **Border:** `#E5E7EB` (Subtle borders)
- **Text Primary:** `#111827` (Dark gray)
- **Text Secondary:** `#6B7280` (Medium gray)
- **Accent:** `#3B82F6` (Blue for interactive elements)
- **Warning:** `#FEF3C7` (Light yellow for data caveats)
- **Success:** `#D1FAE5` (Light green)
- **Error:** `#FEE2E2` (Light red)

## Typography

### Font Stack
- **Primary:** `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`
- **Monospace:** `"Fira Code", "Courier New", monospace` (for data tables)

### Type Scale
- **H1 (Page Title):** 32px / 2rem, font-weight: 700
- **H2 (Section Title):** 24px / 1.5rem, font-weight: 600
- **H3 (Subsection):** 20px / 1.25rem, font-weight: 600
- **Body:** 16px / 1rem, font-weight: 400
- **Small:** 14px / 0.875rem, font-weight: 400
- **Caption:** 12px / 0.75rem, font-weight: 400

## Layout Structure

### Desktop (1920px+)
```
┌─────────────────────────────────────────────────────────────┐
│ Header (Fixed, 60px)                                        │
├──────────┬──────────────────────────────────┬───────────────┤
│          │                                  │               │
│ Control  │   Map Visualization Area (60%)   │   Summary &   │
│ Panel    │                                  │   Charts      │
│ (250px)  │                                  │   (35%)       │
│          │                                  │               │
│          │                                  │               │
└──────────┴──────────────────────────────────┴───────────────┘
```

### Tablet (768px-1024px)
- Control panel collapses to drawer (toggle button)
- Map expands to full width
- Summary panel stacks below map

### Mobile (<768px)
- Full-width map
- Hamburger menu for controls
- Summary cards stack below map
- Drill-down via modal dialogs

## Component Architecture

### Core Components
1. **DashboardLayout** - Main container with header, sidebars, and content area
2. **MapView** - Mapbox GL JS wrapper with choropleth rendering
3. **ControlPanel** - Left sidebar with filters and selectors
4. **SummaryPanel** - Right sidebar with stats, charts, and timeline
5. **TimeSeriesChart** - D3.js line/bar chart component
6. **PoliticalTimeline** - Horizontal timeline for elected officials
7. **DataTable** - Sortable/filterable table view
8. **AdminDashboard** - ETL status and management (admin-only)

### Shared UI Components (shadcn/ui)
- Button, Card, Dialog, Dropdown, Tabs, Tooltip, Badge, Alert

## Data Flow Architecture

### API Integration Pattern
```
Laravel Backend API
        ↓
tRPC Procedures (Proxy Layer)
        ↓
React Query Cache
        ↓
React Components
```

### Expected API Endpoints (Laravel Backend)
- `GET /api/data/administrative-levels` - Hierarchical geographic data
- `GET /api/data/indicators/{level}/{code}/{year}` - Economic/political data
- `GET /api/data/time-series/{level}/{code}` - Time-series data
- `POST /api/export/excel` - Generate Excel file
- `POST /api/export/pdf` - Generate PDF report
- `GET /api/admin/etl-status` - ETL job status (admin only)

### tRPC Procedures (Proxy to Laravel)
```typescript
export const appRouter = router({
  geo: router({
    getLevels: publicProcedure.query(() => /* proxy to Laravel */),
    getRegion: publicProcedure.input(z.object({ level, code })).query(() => /* ... */),
  }),
  indicators: router({
    getByRegion: publicProcedure.input(z.object({ level, code, year })).query(() => /* ... */),
    getTimeSeries: publicProcedure.input(z.object({ level, code })).query(() => /* ... */),
  }),
  export: router({
    excel: protectedProcedure.mutation(() => /* ... */),
    pdf: protectedProcedure.mutation(() => /* ... */),
  }),
  admin: router({
    getETLStatus: adminProcedure.query(() => /* ... */),
    triggerETL: adminProcedure.mutation(() => /* ... */),
    uploadFile: adminProcedure.mutation(() => /* ... */),
  }),
});
```

## Accessibility Standards

### WCAG 2.1 Level AA Compliance
- **Color Contrast:** Minimum 4.5:1 for normal text, 3:1 for large text
- **Keyboard Navigation:** Full support for Tab, Shift+Tab, Enter, Arrow keys
- **Focus Indicators:** Visible 2px outline on all interactive elements
- **ARIA Labels:** Descriptive labels for all buttons, links, and form controls
- **Alternative Text:** Icons paired with text labels or tooltips
- **Screen Reader Support:** Semantic HTML and ARIA landmarks

## Performance Optimizations

### Client-Side
- Lazy-load map tiles and chart data
- Implement React Query caching with 5-minute stale time
- Debounce zoom/pan interactions (300ms)
- Use skeleton loaders during data fetches
- Code-split routes with React.lazy()

### Server-Side
- Cache frequently accessed data in MySQL/TiDB
- Implement rate limiting on API proxy
- Use connection pooling for database queries

## Interaction Patterns

### Micro-interactions
- **Map Click:** 0.5s smooth zoom/pan animation
- **Breadcrumb Click:** Instant navigation with fade transition
- **Time Slider Drag:** Real-time updates (debounced 300ms)
- **View Toggle:** 0.3s fade transition between views
- **Export Button:** Success toast notification after download

### Loading States
- **Initial Load:** Full-page skeleton loader
- **Map Interaction:** Spinner overlay on map
- **Chart Update:** Skeleton bars/lines
- **Data Table:** Shimmer effect on rows

## Responsive Breakpoints

```css
/* Mobile */
@media (max-width: 767px) { /* ... */ }

/* Tablet */
@media (min-width: 768px) and (max-width: 1023px) { /* ... */ }

/* Desktop */
@media (min-width: 1024px) and (max-width: 1919px) { /* ... */ }

/* Large Desktop */
@media (min-width: 1920px) { /* ... */ }
```

## Icon System

Using **Lucide React** for consistent iconography:
- Map: `MapIcon`
- Chart: `BarChart3Icon`
- Table: `TableIcon`
- Download: `DownloadIcon`
- Filter: `FilterIcon`
- Search: `SearchIcon`
- User: `UserIcon`
- Settings: `SettingsIcon`
- Alert: `AlertTriangleIcon`

## Data Caveat Handling

When displaying estimated or disaggregated data (Sub-County and Ward levels):
- Show light yellow banner with warning icon
- Text: "Economic data for this level is an estimate disaggregated from County-level figures."
- Dismissible with close button
- Persist dismissal state in localStorage

## Election Cycle Markers

Mark key election years on time-series charts:
- **2013:** First election under new constitution
- **2017:** Presidential election
- **2022:** Most recent election

Display as vertical dashed lines with year labels on charts.
