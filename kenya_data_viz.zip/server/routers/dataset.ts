import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { getDb } from "../db";
import { economicIndicators, politicalIndicators, administrativeLevels } from "../../drizzle/schema";

export const datasetRouter = router({
  importEconomicData: protectedProcedure
    .input(
      z.object({
        data: z.array(
          z.object({
            region_code: z.string(),
            year: z.number(),
            indicator: z.string(),
            value: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      }

      try {
        // Batch insert economic indicators (optimized for large datasets)
        const batchSize = 100;
        const batches = [];
        
        for (let i = 0; i < input.data.length; i += batchSize) {
          const batch = input.data.slice(i, i + batchSize);
          const values = batch.map((row) => ({
            regionCode: row.region_code,
            year: row.year,
            indicatorType: row.indicator as any,
            value: row.value.toString(),
            isEstimated: 0,
          }));
          batches.push(db.insert(economicIndicators).values(values));
        }

        await Promise.all(batches);

        return {
          success: true,
          rowsImported: input.data.length,
          message: `Successfully imported ${input.data.length} economic indicator rows`,
        };
      } catch (error: any) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Import failed: ${error.message}`,
        });
      }
    }),

  importPoliticalData: protectedProcedure
    .input(
      z.object({
        data: z.array(
          z.object({
            region_code: z.string(),
            year: z.number(),
            party: z.string(),
            candidate: z.string(),
            votes: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      }

      try {
        // Batch insert political indicators (optimized for large datasets)
        const batchSize = 100;
        const batches = [];
        
        for (let i = 0; i < input.data.length; i += batchSize) {
          const batch = input.data.slice(i, i + batchSize);
          const values = batch.map((row) => ({
            regionCode: row.region_code,
            year: row.year,
            indicatorType: "presidential_vote_share" as any,
            value: row.votes.toString(),
            officialName: row.candidate,
            partyName: row.party,
          }));
          batches.push(db.insert(politicalIndicators).values(values));
        }

        await Promise.all(batches);

        return {
          success: true,
          rowsImported: input.data.length,
          message: `Successfully imported ${input.data.length} political indicator rows`,
        };
      } catch (error: any) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Import failed: ${error.message}`,
        });
      }
    }),

  importAdministrativeData: protectedProcedure
    .input(
      z.object({
        data: z.array(
          z.object({
            code: z.string(),
            name: z.string(),
            level: z.enum(["National", "County", "Sub-County", "Ward"]),
            parent_code: z.string().nullable(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      }

      try {
        // Batch insert administrative levels (optimized for large datasets)
        const batchSize = 100;
        const batches = [];
        
        for (let i = 0; i < input.data.length; i += batchSize) {
          const batch = input.data.slice(i, i + batchSize);
          const values = batch.map((row) => ({
            code: row.code,
            name: row.name,
            level: row.level.toLowerCase() as any,
            parentCode: row.parent_code,
            geoJson: null, // GeoJSON will be uploaded separately
          }));
          batches.push(db.insert(administrativeLevels).values(values));
        }

        await Promise.all(batches);

        return {
          success: true,
          rowsImported: input.data.length,
          message: `Successfully imported ${input.data.length} administrative boundary rows`,
        };
      } catch (error: any) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Import failed: ${error.message}`,
        });
      }
    }),

  importGeoJSON: protectedProcedure
    .input(
      z.object({
        features: z.array(
          z.object({
            code: z.string(),
            geometry: z.any(), // GeoJSON geometry object
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      }

      try {
        // Update existing administrative levels with geometry
        const updatePromises = input.features.map(async (feature) => {
          const geometryString = JSON.stringify(feature.geometry);
          await db
            .update(administrativeLevels)
            .set({
              geoJson: geometryString,
            })
            .where(eq(administrativeLevels.code, feature.code));
        });

        await Promise.all(updatePromises);

        return {
          success: true,
          rowsImported: input.features.length,
          message: `Successfully imported ${input.features.length} GeoJSON geometries`,
        };
      } catch (error: any) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: `Import failed: ${error.message}`,
        });
      }
    }),
});
