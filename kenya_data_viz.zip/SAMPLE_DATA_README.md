# Kenya Economic & Political Landscape - Sample Data

## Overview
This directory contains sample CSV files for all 47 Kenya counties with realistic economic and political indicators spanning 2013-2022.

## Files Generated

### 1. sample_data_economic_indicators.csv
**Columns:**
- `county_name`: Name of the county
- `year`: Year (2013-2022)
- `gcp_current_prices`: Gross County Product at current prices (KSh Billions)
- `gcp_constant_prices`: GCP at constant prices (KSh Billions)
- `poverty_rate`: Percentage of population below poverty line
- `population`: Total county population
- `unemployment_rate`: Unemployment percentage
- `inflation_rate`: Annual inflation rate

**Records:** 470 rows (47 counties × 10 years)

### 2. sample_data_political_indicators.csv
**Columns:**
- `county_name`: Name of the county
- `election_year`: Election year (2013, 2017, 2022)
- `governor_name`: Name of elected governor
- `party`: Political party affiliation
- `vote_share`: Percentage of votes received
- `total_votes`: Total votes cast
- `registered_voters`: Number of registered voters
- `turnout_percentage`: Voter turnout percentage

**Records:** 141 rows (47 counties × 3 election years)

### 3. sample_data_administrative_levels.csv
**Columns:**
- `level_type`: Administrative level (National, County)
- `name`: Name of the administrative unit
- `parent_name`: Parent administrative unit
- `code`: Unique identifier code
- `geojson_data`: GeoJSON geometry data (simplified placeholders)

**Records:** 48 rows (1 national + 47 counties)

## How to Upload

1. **Login as Admin**: Navigate to `/admin` route
2. **Click "Upload Dataset"**: Opens the dataset upload page
3. **Select File Type**: Choose the appropriate dataset type
4. **Drag & Drop or Browse**: Upload the CSV file
5. **Review Preview**: Check data preview and validation errors
6. **Import**: Click "Import to Database" to save

## Data Characteristics

- **Realistic Trends**: Data shows 3% annual growth with COVID-19 impact in 2020
- **Urban vs Rural**: Urban counties (Nairobi, Mombasa, Kisumu) have higher GCP and lower poverty rates
- **Political Diversity**: Multiple parties represented across counties
- **Time Series**: Complete data from 2013-2022 for trend analysis

## Notes

- GeoJSON boundaries are simplified placeholders. Replace with actual county boundaries from KNBS.
- Economic values are generated using realistic ranges but are not actual KNBS data.
- Governor names are randomly generated and do not reflect actual elected officials.
- For production use, replace with official data from KNBS and IEBC sources.

## Next Steps

1. Upload these files through the admin dashboard
2. Test the visualization with complete county data
3. Replace with real data from KNBS API when ready
4. Add sub-county and ward level data for drill-down functionality

---
Generated: 2025-11-19 01:53:14
