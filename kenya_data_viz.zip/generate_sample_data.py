#!/usr/bin/env python3
"""
Generate sample CSV data for Kenya Economic & Political Landscape Visualization System
Creates realistic data for all 47 Kenya counties with economic and political indicators
"""

import csv
import random
import json
from datetime import datetime

# All 47 Kenya counties
KENYA_COUNTIES = [
    "Mombasa", "Kwale", "Kilifi", "Tana River", "Lamu", "Taita-Taveta", "Garissa",
    "Wajir", "Mandera", "Marsabit", "Isiolo", "Meru", "Tharaka-Nithi", "Embu",
    "Kitui", "Machakos", "Makueni", "Nyandarua", "Nyeri", "Kirinyaga", "Murang'a",
    "Kiambu", "Turkana", "West Pokot", "Samburu", "Trans-Nzoia", "Uasin Gishu",
    "Elgeyo-Marakwet", "Nandi", "Baringo", "Laikipia", "Nakuru", "Narok", "Kajiado",
    "Kericho", "Bomet", "Kakamega", "Vihiga", "Bungoma", "Busia", "Siaya", "Kisumu",
    "Homa Bay", "Migori", "Kisii", "Nyamira", "Nairobi"
]

# Political parties
PARTIES = ["Jubilee", "ODM", "UDA", "Azimio", "NASA", "TNA", "CORD"]

# Years for time-series data
YEARS = list(range(2013, 2023))

def generate_economic_indicators():
    """Generate economic indicators CSV for all counties"""
    filename = "/home/ubuntu/kenya_data_viz/sample_data_economic_indicators.csv"
    
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['county_name', 'year', 'gcp_current_prices', 'gcp_constant_prices', 
                     'poverty_rate', 'population', 'unemployment_rate', 'inflation_rate']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        
        for county in KENYA_COUNTIES:
            # Base values (Nairobi highest, rural counties lower)
            is_urban = county in ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret"]
            base_gcp = random.uniform(50, 200) if is_urban else random.uniform(10, 60)
            base_population = random.uniform(1000000, 4500000) if county == "Nairobi" else random.uniform(300000, 1500000)
            base_poverty = random.uniform(15, 30) if is_urban else random.uniform(30, 55)
            
            for year in YEARS:
                # Growth over time
                year_factor = 1 + (year - 2013) * 0.03  # 3% annual growth
                covid_impact = 0.95 if year == 2020 else 1.0  # COVID-19 dip in 2020
                
                writer.writerow({
                    'county_name': county,
                    'year': year,
                    'gcp_current_prices': round(base_gcp * year_factor * covid_impact * random.uniform(0.95, 1.05), 2),
                    'gcp_constant_prices': round(base_gcp * 0.85 * year_factor * covid_impact * random.uniform(0.95, 1.05), 2),
                    'poverty_rate': round(base_poverty * (1 - (year - 2013) * 0.01) * random.uniform(0.98, 1.02), 2),
                    'population': int(base_population * year_factor * random.uniform(0.98, 1.02)),
                    'unemployment_rate': round(random.uniform(8, 25), 2),
                    'inflation_rate': round(random.uniform(4, 9), 2)
                })
    
    print(f"✅ Generated: {filename}")
    return filename

def generate_political_indicators():
    """Generate political indicators CSV for all counties"""
    filename = "/home/ubuntu/kenya_data_viz/sample_data_political_indicators.csv"
    
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['county_name', 'election_year', 'governor_name', 'party', 
                     'vote_share', 'total_votes', 'registered_voters', 'turnout_percentage']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        
        election_years = [2013, 2017, 2022]
        
        for county in KENYA_COUNTIES:
            base_voters = random.uniform(200000, 1500000) if county == "Nairobi" else random.uniform(100000, 800000)
            
            for election_year in election_years:
                party = random.choice(PARTIES)
                vote_share = random.uniform(35, 65)
                registered = int(base_voters * (1 + (election_year - 2013) * 0.05))
                turnout = random.uniform(60, 85)
                total_votes = int(registered * (turnout / 100))
                
                # Generate governor name
                first_names = ["John", "Mary", "Peter", "Jane", "David", "Sarah", "James", "Grace", "Patrick", "Anne"]
                last_names = ["Mwangi", "Ochieng", "Kipchoge", "Wanjiru", "Kamau", "Otieno", "Mutua", "Njeri", "Kimani", "Akinyi"]
                governor_name = f"{random.choice(first_names)} {random.choice(last_names)}"
                
                writer.writerow({
                    'county_name': county,
                    'election_year': election_year,
                    'governor_name': governor_name,
                    'party': party,
                    'vote_share': round(vote_share, 2),
                    'total_votes': total_votes,
                    'registered_voters': registered,
                    'turnout_percentage': round(turnout, 2)
                })
        
    print(f"✅ Generated: {filename}")
    return filename

def generate_administrative_levels():
    """Generate administrative levels CSV with simplified GeoJSON"""
    filename = "/home/ubuntu/kenya_data_viz/sample_data_administrative_levels.csv"
    
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['level_type', 'name', 'parent_name', 'code', 'geojson_data']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        
        # National level
        writer.writerow({
            'level_type': 'National',
            'name': 'Kenya',
            'parent_name': '',
            'code': 'KE',
            'geojson_data': ''
        })
        
        # County level with simplified GeoJSON placeholders
        for idx, county in enumerate(KENYA_COUNTIES, start=1):
            # Create simplified bounding box coordinates (placeholder)
            # In production, these would be actual county boundaries
            lat_base = -1.0 + (idx % 7) * 0.5
            lon_base = 36.0 + (idx // 7) * 0.5
            
            geojson = {
                "type": "Feature",
                "properties": {"name": county, "code": f"KE-{idx:02d}"},
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [lon_base, lat_base],
                        [lon_base + 0.4, lat_base],
                        [lon_base + 0.4, lat_base + 0.4],
                        [lon_base, lat_base + 0.4],
                        [lon_base, lat_base]
                    ]]
                }
            }
            
            writer.writerow({
                'level_type': 'County',
                'name': county,
                'parent_name': 'Kenya',
                'code': f"KE-{idx:02d}",
                'geojson_data': json.dumps(geojson)
            })
    
    print(f"✅ Generated: {filename}")
    return filename

def generate_readme():
    """Generate README file explaining the sample data"""
    filename = "/home/ubuntu/kenya_data_viz/SAMPLE_DATA_README.md"
    
    content = """# Kenya Economic & Political Landscape - Sample Data

## Overview
This directory contains sample CSV files for all 47 Kenya counties with realistic economic and political indicators spanning 2013-2022.

## Files Generated

### 1. sample_data_economic_indicators.csv
**Columns:**
- `county_name`: Name of the county
- `year`: Year (2013-2022)
- `gcp_current_prices`: Gross County Product at current prices (KSh Billions)
- `gcp_constant_prices`: GCP at constant prices (KSh Billions)
- `poverty_rate`: Percentage of population below poverty line
- `population`: Total county population
- `unemployment_rate`: Unemployment percentage
- `inflation_rate`: Annual inflation rate

**Records:** 470 rows (47 counties × 10 years)

### 2. sample_data_political_indicators.csv
**Columns:**
- `county_name`: Name of the county
- `election_year`: Election year (2013, 2017, 2022)
- `governor_name`: Name of elected governor
- `party`: Political party affiliation
- `vote_share`: Percentage of votes received
- `total_votes`: Total votes cast
- `registered_voters`: Number of registered voters
- `turnout_percentage`: Voter turnout percentage

**Records:** 141 rows (47 counties × 3 election years)

### 3. sample_data_administrative_levels.csv
**Columns:**
- `level_type`: Administrative level (National, County)
- `name`: Name of the administrative unit
- `parent_name`: Parent administrative unit
- `code`: Unique identifier code
- `geojson_data`: GeoJSON geometry data (simplified placeholders)

**Records:** 48 rows (1 national + 47 counties)

## How to Upload

1. **Login as Admin**: Navigate to `/admin` route
2. **Click "Upload Dataset"**: Opens the dataset upload page
3. **Select File Type**: Choose the appropriate dataset type
4. **Drag & Drop or Browse**: Upload the CSV file
5. **Review Preview**: Check data preview and validation errors
6. **Import**: Click "Import to Database" to save

## Data Characteristics

- **Realistic Trends**: Data shows 3% annual growth with COVID-19 impact in 2020
- **Urban vs Rural**: Urban counties (Nairobi, Mombasa, Kisumu) have higher GCP and lower poverty rates
- **Political Diversity**: Multiple parties represented across counties
- **Time Series**: Complete data from 2013-2022 for trend analysis

## Notes

- GeoJSON boundaries are simplified placeholders. Replace with actual county boundaries from KNBS.
- Economic values are generated using realistic ranges but are not actual KNBS data.
- Governor names are randomly generated and do not reflect actual elected officials.
- For production use, replace with official data from KNBS and IEBC sources.

## Next Steps

1. Upload these files through the admin dashboard
2. Test the visualization with complete county data
3. Replace with real data from KNBS API when ready
4. Add sub-county and ward level data for drill-down functionality

---
Generated: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """
"""
    
    with open(filename, 'w') as f:
        f.write(content)
    
    print(f"✅ Generated: {filename}")
    return filename

if __name__ == "__main__":
    print("🚀 Generating sample data for Kenya Economic & Political Landscape Visualization System\n")
    
    # Generate all sample data files
    economic_file = generate_economic_indicators()
    political_file = generate_political_indicators()
    admin_file = generate_administrative_levels()
    readme_file = generate_readme()
    
    print(f"\n✅ All sample data files generated successfully!")
    print(f"\n📁 Files created:")
    print(f"   1. {economic_file}")
    print(f"   2. {political_file}")
    print(f"   3. {admin_file}")
    print(f"   4. {readme_file}")
    print(f"\n📝 Read {readme_file} for upload instructions")
