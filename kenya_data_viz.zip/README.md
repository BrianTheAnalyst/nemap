# Kenya Economic & Political Landscape Visualization System

A production-ready web application for visualizing Kenya's economic and political data across administrative levels (National, County, Sub-County, Ward) from 2013 to present.

## Features

### 🗺️ Interactive Map Visualization
- **Choropleth maps** powered by Mapbox GL JS
- **Hover tooltips** showing region details and indicator values
- **Click-to-drill-down** functionality for geographic exploration
- **Dynamic legends** with color scales and value ranges
- **Smooth animations** for zoom, pan, and transitions

### 📊 Data Visualization & Charts
- **Time-series charts** built with D3.js showing trends from 2013-present
- **Election cycle markers** (2013, 2017, 2022) for correlation analysis
- **Interactive tooltips** with exact values on hover
- **Political timeline** showing elected officials by year
- **Export functionality** for charts and data

### 🎛️ Advanced Controls
- **Geographic selector** with breadcrumb navigation
- **Indicator tabs** for Economic and Political data
- **Time filter** with year range selection
- **View modes**:
  - Map View (default choropleth)
  - Side-by-Side Compare (Economic vs Political)
  - Data Table View (sortable, filterable, exportable)

### 👨‍💼 Admin Dashboard
- **Role-based access control** (admin-only)
- **ETL status monitoring** with real-time job tracking
- **Manual job triggers** for data refresh
- **File upload** to S3 for data ingestion
- **Job logs** with search and filtering
- **Error tracking** and notifications

### ♿ Accessibility & Responsiveness
- **WCAG 2.1 Level AA** compliant
- **Keyboard navigation** support
- **Screen reader** optimized
- **Reduced motion** support for users with vestibular disorders
- **High contrast mode** support
- **Mobile-first** responsive design
- **Touch-friendly** controls for tablets and phones

## Technology Stack

### Frontend
- **React 19** with TypeScript
- **Tailwind CSS 4** for styling
- **Mapbox GL JS** for interactive maps
- **D3.js** for data visualizations
- **tRPC** for type-safe API calls
- **Wouter** for client-side routing
- **shadcn/ui** for UI components

### Backend
- **Express 4** with TypeScript
- **tRPC 11** for API layer
- **Drizzle ORM** for database operations
- **MySQL/TiDB** for data storage
- **Manus OAuth** for authentication

### Infrastructure
- **Vite** for build tooling
- **pnpm** for package management
- **S3** for file storage
- **Manus Platform** for deployment

## Project Structure

```
kenya_data_viz/
├── client/                 # Frontend application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   │   ├── ControlPanel.tsx
│   │   │   ├── MapVisualization.tsx
│   │   │   ├── TimeSeriesChart.tsx
│   │   │   ├── SummaryPanel.tsx
│   │   │   ├── DataTableView.tsx
│   │   │   └── SideBySideView.tsx
│   │   ├── pages/         # Page components
│   │   │   ├── Home.tsx
│   │   │   └── Admin.tsx
│   │   ├── lib/           # Utilities and configs
│   │   └── index.css      # Global styles
│   └── public/            # Static assets
├── server/                # Backend application
│   ├── routers.ts        # tRPC procedures
│   ├── db.ts             # Database helpers
│   └── _core/            # Framework code
├── drizzle/              # Database schema
│   └── schema.ts
└── shared/               # Shared types and constants
```

## Database Schema

### Administrative Levels
- **administrative_levels**: Geographic boundaries (National, County, Sub-County, Ward)
  - Stores GeoJSON geometry for map rendering
  - Hierarchical structure with parent-child relationships

### Economic Indicators
- **economic_indicators**: GCP, poverty rates, population estimates
  - Time-series data from 2013-present
  - Cached from KNBS API

### Political Indicators
- **political_indicators**: Vote shares, elected officials, party affiliations
  - Election results by year and region
  - Cached from IEBC API

### ETL Jobs
- **etl_jobs**: Job logs for admin dashboard
  - Tracks data ingestion status
  - Records errors and processing times

## Getting Started

### Prerequisites
- Node.js 22+
- pnpm 9+
- MySQL/TiDB database

### Installation

```bash
# Install dependencies
pnpm install

# Set up database
pnpm db:push

# Start development server
pnpm dev
```

### Environment Variables

All required environment variables are automatically injected by the Manus platform:

- `DATABASE_URL` - MySQL connection string
- `JWT_SECRET` - Session signing secret
- `VITE_APP_TITLE` - Application title
- `BUILT_IN_FORGE_API_KEY` - Manus API key
- `OAUTH_SERVER_URL` - OAuth server URL

## Usage

### For End Users

1. **Explore the Map**
   - Select a geographic level from the dropdown
   - Choose an economic or political indicator
   - Adjust the time filter to view historical data
   - Click regions to drill down to sub-levels

2. **View Trends**
   - Check the summary panel for key statistics
   - Review time-series charts for trend analysis
   - Note election cycle markers for correlation

3. **Compare Data**
   - Switch to "Compare" view mode
   - See economic and political data side-by-side
   - Analyze correlations between indicators

4. **Export Data**
   - Switch to "Table" view mode
   - Search and filter data
   - Copy to clipboard or export to Excel

### For Administrators

1. **Access Admin Dashboard**
   - Click user avatar → "Admin Dashboard"
   - View ETL job status and logs

2. **Trigger Manual Runs**
   - Click "Trigger Manual Run"
   - Select data source
   - Monitor job progress

3. **Upload Files**
   - Click "Upload File"
   - Select CSV or Excel file
   - File is uploaded to S3 for processing

## API Integration

The system is designed to integrate with:

- **KNBS API** for economic indicators
- **IEBC API** for political data
- **GIS Services** for administrative boundaries

Backend procedures are defined in `server/routers.ts` and can be extended to call external APIs.

## Accessibility Features

- **Keyboard Navigation**: All interactive elements are keyboard accessible
- **Screen Reader Support**: Proper ARIA labels and semantic HTML
- **Focus Management**: Clear focus indicators and logical tab order
- **Color Contrast**: WCAG AA compliant color ratios
- **Responsive Text**: Scales appropriately on all devices
- **Reduced Motion**: Respects user's motion preferences

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance

- **Lazy Loading**: Components load on demand
- **Code Splitting**: Optimized bundle sizes
- **Caching**: API responses cached in database
- **Debouncing**: Search and filter inputs debounced
- **Virtualization**: Large tables use virtual scrolling

## Security

- **Authentication**: Manus OAuth with JWT sessions
- **Authorization**: Role-based access control (RBAC)
- **CSRF Protection**: Built into tRPC
- **XSS Prevention**: React's automatic escaping
- **SQL Injection**: Drizzle ORM parameterized queries

## Deployment

The application is deployed on the Manus platform:

1. Save a checkpoint: `webdev_save_checkpoint`
2. Click "Publish" in the management UI
3. Application is live at `https://{project}.manus.space`

## Contributing

This is a demo project built for the Kenya Economic and Political Landscape Visualization System. For production use, integrate with real APIs and update the sample data.

## License

MIT License - see LICENSE file for details

## Support

For issues or questions, contact the development team or submit an issue in the project repository.

---

**Built with ❤️ using React, Mapbox GL JS, D3.js, and the Manus Platform**
